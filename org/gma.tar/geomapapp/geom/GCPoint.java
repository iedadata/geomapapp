package org.geomapapp.geom;

public class GCPoint {
	public double longitude;
	public double latitude;
	public double radius;
	public GCPoint( double longitude,
			double latitude,
			double radius) {
		this.longitude = longitude;
		this.latitude = latitude;
		this.radius = radius;
	}
	public XYZ getXYZ() {
		return XYZ.GCPoint_to_XYZ(this);
	}
}
