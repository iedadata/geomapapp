package org.geomapapp.map;

import org.geomapapp.proj.*;
import org.geomapapp.util.*;

import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.text.NumberFormat;
import java.awt.print.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.util.Vector;

import com.sun.image.codec.jpeg.*;

/**
 	XBMap loads and manipulates the map.
 */
public class XBMap extends haxby.util.ScaledComponent 
				implements Scrollable {

	/**
	 	Projection Object for the map
	 */
	Protected MapProjection proj;

	/**
	 	map's bounds in projection coordinates
	 */
	Protected Rectangle2D mapBounds;
	
	/**
	 	Overlay objects added to the map.
	 */
	protected Vector overlays;
	
	/**
	 	Not implemented.
	 */
	protected Vector mapInsets;
	
	/**
	 	Used to scroll the map.
	 */
	protected JScrollPane scrollPane = null;
	
//	/**
//	 	MapBorder draws Latitude/Longitude annotations on the border.
//	 */
//	protected MapBorder mapBorder = null;
	
	/**
	 	For CylindricalProjection, wrap = nodes per 360 degrees; otherwise wrap = -1.
	 */
	protected double wrap;
	
	public XBMap(MapProjection proj, Rectangle2D bounds) {
		this.proj = proj;
		mapBounds = bounds;
		width = (int)Math.rint(bounds.width());
		height = (int)Math.rint(bounds.height());
		overlays = new Vector();
		setLayout( null );
		try {
			CylindricalProjection p = (CylindricalProjection) proj;
			wrap = Math.rint(360.*(p.getX(10.)-p.getX(9.)));
		} catch (ClassCastException ex) {
			wrap = -1.;
		}
	}
	
	/**
	 	Assigns the scrollPane.
	 */
	public void addNotify() {
		super.addNotify();
		Container c = getParent();
		while(c != null) {
			if( c instanceof JScrollPane ) {
				scrollPane = (JScrollPane) c;
				return;
			}
			c = c.getParent();
		}
		scrollPane = null;
	}
	
	public void removeNotify() {
		super.removeNotify();
		scrollPane = null;
	}
	/**
	 	Get wrap value.
	 	@return wrap value.
	 */
	public double getWrap() {
		return wrap;
	}
	
//	/**
//		Sets the map border.
//		@param border map border to set.
//	 */
//	public void setMapBorder( MapBorder border ) {
//		mapBorder = border;
//	}
//	
//	/**
//	 	Get the map border.
//	 	@return the map border.
//	 */
//	public MapBorder getMapBorder() {
//		return mapBorder;
//	}
	
	/**
	 	Adds Overlay object to map.
	 	@param overlay Overlay object to add.
	 */
	public void addOverlay( Overlay overlay ) {
		overlays.add(overlay );
	}

	/**
	 	Removes Overlay object from map.
	 	@param overlay Overlay object to remove.
	 */
	public void removeOverlay( Overlay overlay ) {
		overlays.remove( overlay );
	}
	
	/**
	 	Gets the projection.
	 	@return the projection.
	 */
	public MapProjection getProjection() {
		return proj;
	}
/*
********* Methods implementing the javax.swing.Scrollable interface *********
/*
	public Dimension getPreferredScrollableViewportSize() {
		return getPreferredSize();
	}
	public int getScrollableUnitIncrement(Rectangle visibleRect,
				int orientation, int direction) {
		if( orientation == SwingConstants.VERTICAL) return 10;
		int newX = visibleRect.x + (direction>0 ? 10 : -10);
		if( wrap>0. ) {
			int dx = (int) (wrap*zoom);
			int test = getPreferredSize().width - visibleRect.width;
			while( newX<0 ) newX += dx;
			while( newX>test ) newX -= dx;
		}
		return (direction>0) ? (newX-visibleRect.x) : -(newX-visibleRect.x);
	} 
	public int getScrollableBlockIncrement(Rectangle visibleRect,
				int orientation, int direction) {
		if( orientation == SwingConstants.VERTICAL) return visibleRect.height/2;
		int dx = visibleRect.width/2;
		int newX = visibleRect.x + (direction>0 ? dx : -dx);
		if( wrap>0. ) {
			dx = (int) (wrap*zoom);
			int test = getPreferredSize().width - visibleRect.width;
			while( newX<0 ) newX += dx;
			while( newX>test ) newX -= dx;
		}
		return (direction>0) ? (newX-visibleRect.x) : -(newX-visibleRect.x);
	} 
	public boolean getScrollableTracksViewportWidth() { return false; }
	public boolean getScrollableTracksViewportHeight() { return false; }
	
	/**
	 	Paints designated graphics.
	 	@param g Graphics object used for drawing
	 */
	public void paint( Graphics g ) {
		Graphics2D g2 = (Graphics2D)g;
		Dimension dim = getPreferredSize();
		Rectangle r = getVisibleRect();
		if(r.width>dim.width) r.width = dim.width;
		if(r.height>dim.height) r.height = dim.height;
		AffineTransform at = new AffineTransform();
		Rectangle interior = new Rectangle();
		if(mapBorder != null) {
			mapBorder.paintBorder(this, g, r.x, r.y, r.width, r.height);
			interior = mapBorder.getInteriorRectangle(this,
					r.x, r.y, r.width, r.height);
			g2.clip( interior );
			Insets ins = mapBorder.getBorderInsets(this);
			g2.translate(ins.left, ins.top);
		}
// Mac fix?
		BufferedImage im = new BufferedImage(r.width, r.height, BufferedImage.TYPE_INT_RGB);
		Graphics2D g2d = im.createGraphics();
		g2d.setRenderingHint( RenderingHints.KEY_INTERPOLATION,
				RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2d.setColor( Color.white );
		g2d.fillRect( 0, 0, r.width, r.height);
		g2d.translate( -r.x, -r.y );
		g2d.scale(zoom, zoom);
		int i=0;
		if(image != null)g2d.drawImage(image, 0, 0, this);
		while( i<overlays.size() && overlays.get(i) instanceof MapOverlay ) {
			((Overlay)overlays.get(i++)).draw(g2d);
		}
		if( image != null || i!=0 ) {
			g2.translate( r.x, r.y);
			g2.drawImage( im, 0, 0, this);
			g2.translate( -r.x, -r.y);
		}
		g2.scale(zoom, zoom);
		int i0=i;
		for( i=i0 ; i<overlays.size() ; i++) {
			((Overlay)overlays.get(i)).draw(g2);
		}
		if( mapInsets==null || mapInsets.size()==0 ) return;
		g2.scale( 1./zoom, 1./zoom );
		g2.translate( r.x, r.y );
		for( i=0 ; i<mapInsets.size() ; i++) {
			((MapInset)mapInsets.get(i)).draw( g2, interior.width, interior.height );
		}
	}
}
