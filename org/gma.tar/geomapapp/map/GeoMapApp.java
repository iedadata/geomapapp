package org.geomapapp.map;

import org.geomapapp.proj.*;

public class GeoMapApp {
	private static String VERSION = "1.0b";
	/**
	* Mercator projection system
	*/
	public static final int MERCATOR = 0;
	/**
	* South Polar Stereographic projection system
	*/
	int which;	// 0 or 1

	public static final int SOUTH_POLAR = 1;

	static String BASE_URL = "http://ocean-ridge.ldeo.columbia.edu/";
	static String TILE_URL = BASE_URL;
	
	public GeoMapApp( String baseURL ) {
		if( baseURL!=null ) {
			BASE_URL=baseURL;
			if( !BASE_URL.endsWith("/")) BASE_URL+="/";
		}
		which = selectMap();
		if( which==-1 ) System.exit(0);
	}
	int selectMap() {
		BaseMapSelect sel = new BaseMapSelect();
		return sel.getBaseMap();
	}
	public static void main( String[] args ) {
		new GeoMapApp( null );
	}
}
