package org.geomapapp.map;

import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;

import com.sun.image.codec.jpeg.*;

public class BaseMapSelect implements ActionListener {
	public BaseMapSelect() {
	}
	JLabel selected;
	JToggleButton[] maps;
	public int getBaseMap() {
		ButtonGroup bg = new ButtonGroup();
		maps = new JToggleButton[2];
		try {
			BufferedInputStream in = new BufferedInputStream(
				(new java.net.URL(GeoMapApp.BASE_URL
					+"MapApp/smallMerc.jpg")).openStream());
			JPEGImageDecoder decoder = JPEGCodec.createJPEGDecoder(in);
			BufferedImage image = decoder.decodeAsBufferedImage();
			in.close();
			maps[0] = new JToggleButton( new ImageIcon(image), true );
		} catch (Exception ex) {
			maps[0] = new JToggleButton( "Mercator", true );
		}
		try {
			BufferedInputStream in = new BufferedInputStream(
				(new java.net.URL(GeoMapApp.BASE_URL
					+"MapApp/smallSP.jpg")).openStream());
			JPEGImageDecoder decoder = JPEGCodec.createJPEGDecoder(in);
			BufferedImage image = decoder.decodeAsBufferedImage();
			in.close();
			maps[1] = new JToggleButton( new ImageIcon(image) );
		} catch (Exception ex) {
			maps[1] = new JToggleButton( "South Polar" );
		}
		bg.add(maps[0]);
		bg.add(maps[1]);
		maps[0].addActionListener( this);
		maps[1].addActionListener( this);
		JPanel panel = new JPanel( new BorderLayout() );
		panel.add( maps[1], "East" );
		panel.add( maps[0], "West" );
		JLabel label = new JLabel( "Select a Base Map" );
		label.setForeground( Color.black);
		panel.add( label,"North" );
		selected = new JLabel( "Mercator Selected" );
		selected.setForeground( Color.black);
		panel.add( selected,"South" );
		int ok = JOptionPane.showConfirmDialog( null, panel, "Choose a Base Map",
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		if(ok==JOptionPane.CANCEL_OPTION) ok = -1;
		else if( maps[0].isSelected() ) ok = 0;
		else ok = 1;
		maps[0] = null;
		maps[1] = null;
		return ok;
	}
	public void actionPerformed(ActionEvent evt) {
		if( maps[0].isSelected() ) {
			selected.setText("Mercator Selected" );
		} else {
			selected.setText("South Polar Selected" );
		}
	}
}
