package org.geomapapp.map;

public abstract interface XBMapOverlay {

	/**
	*	Called by XBMap when drawing
	*	@param g The <code>Graphics2D</code> context in which to paint
	*	@param trans Transforms map points to coordinates in the
	*		drawing context.
	*	@param bounds Drawing area in un-transformed map coordinates
	*/
	public abstract void draw(
			java.awt.Graphics2D g,
			java.awt.geom.AffineTransform trans,
			java.awt.geom.Rectangle2D bounds);

	/**
	*	Returns the name of this overlay.  Implementations should
	*		override the <code>toString()</code> method of
	*		<code>Object</code> to return the same name.
	*	@return The name of this overlay.
	*/
	public abstract String getName();

	/**
	*	Set the name of this overlay.
	*	@param name The new name of the overlay
	*/
	public abstract void setName(String name);

	/**
	*	Returns whether or not to draw this overlay.
	*	@return <code>true</code> if this overlay is drawn,
			<code>false</code> otherwise.
	*/
	public abstract boolean isVisible();

	/**
	*	Sets the visibility of this overlay.
	*	@param tf <code>true</code> if this overlay is to be drawn,
	*		<code>false</code> otherwise.
	*/
	public abstract void setVisible(boolean tf);
}
