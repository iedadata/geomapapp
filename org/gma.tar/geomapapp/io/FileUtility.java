package org.geomapapp.io;

import java.io.*;

public class FileUtility {
	public static void copyAll(File fromDir, File toDir) throws IOException {
		File[] files = fromDir.listFiles();
		for( int k=0 ; k<files.length ; k++) {
			File to = new File(toDir, files[k].getName());
			if( files[k].isDirectory() ) {
				to.mkdir();
				copyAll( files[k], to );
			} else {
				copy( files[k], to);
			}
		}
	}
	public static void copy(File from, File to) throws IOException {
		if( !to.exists() ) {
			File dir = to.getParentFile();
			if(!dir.exists()) dir.mkdirs();
		}
		byte[] buf = new byte[32768];
		BufferedInputStream in = new BufferedInputStream(
			new FileInputStream(from), 32768);
		BufferedOutputStream out = new BufferedOutputStream(
			new FileOutputStream(to), 32768);
		int len=32768;
		int offset = 0;
		while( true ) {
			len=in.read(buf);
			if( len==-1 ) {
				in.close();
				out.close();
				return;
			}
			out.write( buf, 0, len);
		}
	}
}
