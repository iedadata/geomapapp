package org.geomapapp.io;

import javax.swing.tree.*;
import java.io.*;

public class MutableFileNode extends FileNode
		implements MutableTreeNode {
	public MutableFileNode(File file, MutableFileNode parent) {
		super(file, parent);
	}
	public void insert(MutableTreeNode child, int index) {
		if( children==null ) createChildren();
		children.insertElementAt(child, index);
	}
	public void remove(int index) {
		children.remove(index);
	}
	public void remove(MutableTreeNode child) {
		children.remove(child);
	}
	public void removeFromParent() {
		parent.children.remove(this);
	}
	public void setParent(MutableTreeNode parent) {
		this.parent = (MutableFileNode)parent;
	}
	public void setUserObject(Object obj) {
	}
	public static void main(String[] args) {
		FileNode root=null;
		if( args.length==0 ) {
			String dir = System.getProperty("user.dir");
			root = new MutableFileNode( new File(dir), null);
		} else {
			root = new MutableFileNode( new File(args[0]), null);
		}
		DefaultTreeModel model = new DefaultTreeModel(root, true);
		javax.swing.JFrame frame = new javax.swing.JFrame(root.toString());
		javax.swing.JTree tree = new javax.swing.JTree(model);
		tree.setEditable( true);
		tree.setDragEnabled(true);
		frame.getContentPane().add(new javax.swing.JScrollPane(tree));
		frame.pack();
		frame.show();
		frame.setDefaultCloseOperation(
			frame.EXIT_ON_CLOSE);
	}
}
