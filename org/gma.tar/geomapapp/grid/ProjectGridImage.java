package org.geomapapp.grid;

import org.geomapapp.geom.*;

import java.awt.image.BufferedImage;
import java.awt.geom.Point2D;
import java.awt.Point;

public class ProjectGridImage {
	public final static double EARTH_RADIUS = 6370997.0;
	Grid2D grid;
	BufferedImage gridImage;
	double ve = 1.;
	XYZ[][] xyz = null;
	double[] lats, clat, slat;
	double[] lons, clon, slon;
	public ProjectGridImage( Grid2D grid, BufferedImage image) {
		this.grid = grid;
		if( grid.getProjection() instanceof CylindricalProjection ) {
			CylindricalProjection proj = (CylindricalProjection)grid.getProjection();
			int[] dims = grid.getDimensions();
			lons = new double[dims[0]];
			clon = new double[dims[0]];
			slon = new double[dims[0]];
			for( int x=0 ; x<dims[0] ; x++) {
				lons[x] = proj.getLongitude( (double)x );
				double a = Math.toRadians(lons[x]);
				clon[x] = Math.cos(a);
				slon[x] = Math.sin(a);
			}
			lats = new double[dims[1]];
			clat = new double[dims[1]];
			slat = new double[dims[1]];
			for( int y=0 ; y<dims[0] ; y++) {
				lats[y] = proj.getLatitude( (double)y );
				double a = Math.toRadians(lats[y]);
				clat[y] = Math.cos(a);
				slat[y] = Math.sin(a);
			}
		} else {
			lats = null;
			lons= null;
		}
		gridImage = image;
		xyz = null;
		ve = 1.;
	}
	public void setVE(double ve) {
		this.ve = ve;
	}
	XYZ[] computeXYZ( int x, int y ) {
		double v00 = grid.valueAt(x, y);
		if( Double.isNaN(v00) ) return null;
		double v10 = grid.valueAt(x+1, y);
		if( Double.isNaN(v10) ) return null;
		double v01 = grid.valueAt(x, y+1);
		if( Double.isNaN(v01) ) return null;
		double v11 = grid.valueAt(x+1, y+1);
		if( Double.isNaN(v11) ) return null;
		XYZ[] xyz = new XYZ[2];
		if( lats!=null ) {
			v00 = EARTH_RADIUS + ve*v00;
			XYZ p00 = new XYZ( v00*clat[y]*clon[x], v00*clat[y]*slon[x], v00*slat[y]);
			v10 = EARTH_RADIUS + ve*v10;
			XYZ p10 = new XYZ( v10*clat[y]*clon[x+1], v10*clat[y]*slon[x+1], v10*slat[y]);
			v11 = EARTH_RADIUS + ve*v11;
			XYZ p11 = new XYZ( v11*clat[y+1]*clon[x+1], v11*clat[y+1]*slon[x+1], v11*slat[y+1]);
			v01 = EARTH_RADIUS + ve*v01;
			XYZ p01 = new XYZ( v01*clat[y+1]*clon[x], v01*clat[y+1]*slon[x], v01*slat[y+1]);
			xyz[1] = p11.minus(p00).cross( p10.minus(p01) ).normalize();
			xyz[0] = p00.plus(p01).plus(p10).plus(p11).times(.25);
			return xyz;
		}
		Point2D p = grid.getProjection().getRefXY(
				new Point2D.Double(x, y));
		GCPoint gp = new GCPoint( p.getX(), p.getY(), EARTH_RADIUS + ve*v00);
		XYZ p00 = gp.getXYZ();
		p = grid.getProjection().getRefXY(
				new Point2D.Double(x+1, y));
		gp = new GCPoint( p.getX(), p.getY(), EARTH_RADIUS + ve*v10);
		XYZ p10 = gp.getXYZ();
		p = grid.getProjection().getRefXY(
				new Point2D.Double(x+1, y+1));
		gp = new GCPoint( p.getX(), p.getY(), EARTH_RADIUS + ve*v11);
		XYZ p11 = gp.getXYZ();
		p = grid.getProjection().getRefXY(
				new Point2D.Double(x, y+1));
		gp = new GCPoint( p.getX(), p.getY(), EARTH_RADIUS + ve*v01);
		XYZ p01 = gp.getXYZ();
		xyz[1] = p11.minus(p00).cross( p10.minus(p01) ).normalize();
		xyz[0] = p00.plus(p01).plus(p10).plus(p11).times(.25);
		return xyz;
	}
	public BufferedImage project( Perspective3D pers,
				BufferedImage projectedImage,
				Point2D center) {
		int w = projectedImage.getWidth();
		int h = projectedImage.getHeight();
		double[][] zbuffer = new double[h][w];
		for( int y=0 ; y<h ; y++) {
			for( int x=0 ; x<w ; x++) {
				zbuffer[y][x]=Double.NaN;
			}
		}
		return project( pers, projectedImage, center, zbuffer);
	}
	public BufferedImage project( Perspective3D pers,
				BufferedImage projectedImage,
				Point2D center,
				double[][] zbuffer) {
		int[] size = grid.getDimensions();
		int width = size[0];
		int height = size[1];
		double cx = center.getX();
		double cy = center.getY();
		XYZ[][][] rows = new XYZ[2][width-1][];
		for( int x=0 ; x<width-1 ; x++) {
			rows[0][x] = computeXYZ(x,0);
			if( rows[0][x]==null ) continue;
			if( rows[0][x][1].dot(pers.minusVP(rows[0][x][0]))<=0.) {
				rows[0][x]=null;
				continue;
			}
			rows[0][x][0] = pers.forward( rows[0][x][0] );
			if( rows[0][x][0]==null ) continue;
			rows[0][x][0].x += cx;
			rows[0][x][0].y += cy;
		}
		int m = 0;
		XYZ[] pts = new XYZ[3];
		int[] cols = new int[3];
		for( int y=0 ; y<height-2 ; y++) {
			int m1 = m;
			m = (m+1)%2;
			for( int x=0 ; x<width-1 ; x++) {
				rows[m][x] = computeXYZ(x,y+1);
				if( rows[m][x]==null ) continue;
				if( rows[m][x][1].dot(pers.minusVP(rows[m][x][0]))<=0.) {
					rows[m][x]=null;
					continue;
				}
				rows[m][x][0] = pers.forward( rows[m][x][0] );
				if( rows[m][x]==null ) continue;
				rows[m][x][0].x += cx;
				rows[m][x][0].y += cy;
			}
			for( int x=0 ; x<width-2 ; x++) {
				int n=0;
				if( rows[m1][x]!=null ) {
					pts[n] = rows[m1][x][0];
					cols[n++] = gridImage.getRGB(x, y);
				}
				if( rows[m1][x+1]!=null ) {
					pts[n] = rows[m1][x+1][0];
					cols[n++] = gridImage.getRGB(x+1, y);
				}
				if( n==0 ) continue;
				if( rows[m][x+1]!=null ) {
					pts[n] = rows[m][x+1][0];
					cols[n++] = gridImage.getRGB(x+1, y+1);
					if( n==3 ) {
						render( projectedImage, zbuffer, pts, cols);
						if( rows[m][x]==null )continue;
						pts[1] = rows[m][x][0];
						cols[1] = gridImage.getRGB(x, y+1);
						render( projectedImage, zbuffer, pts, cols);
						continue;
					}
				}
				if( n<2 ) continue;
				if( rows[m][x]!=null ) {
					pts[n] = rows[m][x][0];
					cols[n++] = gridImage.getRGB(x, y+1);
				}
				if( n==3 ) render( projectedImage, zbuffer, pts, cols);
			}
		}
		return projectedImage;
	}
	void render( BufferedImage im, double[][] z, XYZ[] pts, int[] cols) {
			//
			//  Are points colinear?
			//
		XYZ dp1 = pts[1].minus(pts[0]);
		XYZ dp2 = pts[2].minus(pts[0]);
		double den = dp1.x*dp2.y-dp2.x*dp1.y;
		if( den==0. )return;

		int p1 = pts[0].y<pts[1].y ? 0 : 1;
		int p3 = (p1+1)%2;
		if( pts[p1].y>pts[2].y ) p1 = 2;
		else if( pts[2].y>pts[p3].y ) p3 = 2;
		if( Math.floor(pts[p3].y) < Math.ceil(pts[p1].y) )return;

		int q1 = pts[0].x<pts[1].x ? 0 : 1;
		int q3 = (q1+1)%2;
		if( pts[q1].x>pts[2].x ) q1 = 2;
		else if( pts[2].x>pts[q3].x ) q3 = 2;
		if( Math.floor(pts[q3].x) < Math.ceil(pts[q1].x) )return;

		double a = (dp1.z*dp2.y - dp2.z-dp1.y) / den;
		double b = (dp2.z*dp1.x - dp1.z-dp2.x) / den;
		if( Math.floor(pts[q3].x)-Math.ceil(pts[q1].x)
				> Math.floor(pts[p3].y)-Math.ceil(pts[p1].y)) {

			if( pts[p3].y==pts[p1].y )return;
			int p2 = 3-p1-p3;

			int y1 = (int)Math.ceil(pts[p1].y);
			int y2 = (int)Math.ceil(pts[p2].y);
			if( y1<0 ) y1=0;
			if( y2>z.length )y2=z.length;
			int y3 = (int)Math.ceil(pts[p2].y);
			if( y3>z.length )y3=z.length;
			double dxdy1 = (pts[p3].x-pts[p1].x) / (pts[p3].y-pts[p1].y);
			boolean normal = pts[p1].x + dxdy1*(pts[p2].y-pts[p1].y) < pts[p2].x;
			int ix1, ix2;
			ix1 = ix2 = 0;
			if( y2>y1 ) {
				double dxdy2 = (pts[p2].x-pts[p1].x) / (pts[p2].y-pts[p1].y);
				for( int y=y1 ; y<y2 ; y++) {
					double x1 = pts[p1].x + dxdy1*(y-pts[p1].y);
					double x2 = pts[p1].x + dxdy2*(y-pts[p1].y);
					if( normal ) {
						ix1 = (int)Math.ceil(x1);
						ix2 = (int)Math.floor(x2);
					} else {
						ix1 = (int)Math.ceil(x2);
						ix2 = (int)Math.floor(x1);
					}
					for( int ix=ix1 ; ix<=ix2 ; ix++ ) {
						double t = pts[0].z + a*(ix-pts[0].x) + b*(y-pts[0].y);
						if( Double.isNaN(z[y][ix]) || t<z[y][ix] ) {
							z[y][ix] = t;
						}
					}
				}
			}
			if( y3>y2 ) {
				double dxdy2 = (pts[p2].x-pts[p3].x) / (pts[p2].y-pts[p3].y);
				for( int y=y2 ; y<y3 ; y++) {
					double x1 = pts[p1].x + dxdy1*(y-pts[p1].y);
					double x2 = pts[p3].x + dxdy2*(y-pts[p3].y);
					if( normal ) {
						ix1 = (int)Math.ceil(x1);
						ix2 = (int)Math.floor(x2);
					} else {
						ix1 = (int)Math.ceil(x2);
						ix2 = (int)Math.floor(x1);
					}
					for( int ix=ix1 ; ix<=ix2 ; ix++ ) {
						double t = pts[0].z + a*(ix-pts[0].x) + b*(y-pts[0].y);
						if( Double.isNaN(z[y][ix]) || t<z[y][ix] ) {
							z[y][ix] = t;
						}
					}
				}
			}
		} else {
			p1 = q1;
			p3 = q3;
			if( pts[p3].x==pts[p1].x )return;
			int p2 = 3-p1-p3;

			int x1 = (int)Math.ceil(pts[p1].x);
			int x2 = (int)Math.ceil(pts[p2].x);
			if( x1<0 ) x1=0;
			if( x2>z[0].length )x2=z[0].length;
			int x3 = (int)Math.ceil(pts[p2].x);
			if( x3>z[0].length )x3=z[0].length;

			double dydx1 = (pts[p3].y-pts[p1].y) / (pts[p3].x-pts[p1].x);
			boolean normal = pts[p1].y + dydx1*(pts[p2].x-pts[p1].x) < pts[p2].y;
			int iy1, iy2;
			iy1 = iy2 = 0;
			if( x2>x1 ) {
				double dydx2 = (pts[p2].y-pts[p1].y) / (pts[p2].x-pts[p1].x);
				for( int ix=x1 ; ix<x2 ; ix++) {
					double y1 = pts[p1].y + dydx1*(ix-pts[p1].x);
					double y2 = pts[p1].y + dydx2*(ix-pts[p1].x);
					if( normal ) {
						iy1 = (int)Math.ceil(y1);
						iy2 = (int)Math.floor(y2);
					} else {
						iy1 = (int)Math.ceil(y2);
						iy2 = (int)Math.floor(y1);
					}
					for( int iy=iy1 ; iy<=iy2 ; iy++ ) {
						double t = pts[0].z + a*(ix-pts[0].x) + b*(iy-pts[0].y);
						if( Double.isNaN(z[iy][ix]) || t<z[iy][ix] ) {
							z[iy][ix] = t;
						}
					}
				}
			}
			if( x3>x2 ) {
				double dydx2 = (pts[p2].y-pts[p3].y) / (pts[p2].x-pts[p3].x);
				for( int ix=x2 ; ix<x3 ; ix++) {
					double y1 = pts[p1].y + dydx1*(ix-pts[p1].x);
					double y2 = pts[p3].y + dydx2*(ix-pts[p3].x);
					if( normal ) {
						iy1 = (int)Math.ceil(y1);
						iy2 = (int)Math.floor(y2);
					} else {
						iy1 = (int)Math.ceil(y2);
						iy2 = (int)Math.floor(y1);
					}
					for( int iy=iy1 ; iy<=iy2 ; iy++ ) {
						double t = pts[0].z + a*(ix-pts[0].x) + b*(iy-pts[0].y);
						if( Double.isNaN(z[iy][ix]) || t<z[iy][ix] ) {
							z[iy][ix] = t;
						}
					}
				}
			}
		}
	}
}
