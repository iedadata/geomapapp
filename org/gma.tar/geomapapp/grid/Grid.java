/*
 * @(#)Grid.java	0.1	03/12/19
 *
 */
package org.geomapapp.grid;

/**
 * A container for an N-dimensional grid of numerical values
 * @author Bill Haxby
 */
public interface Grid {

	/**
	 * Returns the dimensions of the grid.
	 * @return An int array of dimension N where N is the 
	 *	number of dimensions in the grid, and the 
	 *	values are dimensions.
	 */
	public int[] getDimensions();

	/**
	 * Returns the value of the grid at indices r.
	 * @param r An int array of dimension N which defines 
	 *	indices of a grid node.
	 * @return The grid value at the specified node.
	 * @throws ArrayIndexOutOfBoundsException if the dimension
	 *	of <code>r</code> is less than <code>getDimensions().length</code>
	 *	or if the point specified <code>r</code> is outside the grid.
	 */
	public double valueAt(int[] r);

	/**
	 * Sets the value of a grid node.
	 * @param r An int array of dimension N which defines
	 *	indices of a grid node.
	 * @param val A double value to replace the current
	 *	grid value at the specified node.
	 * @throws ArrayIndexOutOfBoundsException if the dimension
	 *	of <code>r</code> is less than <code>getDimensions().length</code>
	 *	or if the point specified <code>r</code> is outside the grid.
	 */
	public void setValue(int[] r, double val);
}
