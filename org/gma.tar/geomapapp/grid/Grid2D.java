/*
 * @(#)Grid.java	0.1	03/12/19
 *
 */
package org.geomapapp.grid;

import org.geomapapp.proj.*;
import java.awt.geom.*;
import java.awt.Rectangle;

/**
 * A container for an 2-dimensional grid of numerical values.
 * If a map projection and/or an affine transform are specified,
 * then grid node locations (x, y) are related to geographic coordinate
 * by first applying the inverse transform, then the inverse projection.
 * @see MapProjection
 * @see AffineTransform
 * @author Bill Haxby
 */
public abstract class Grid2D {

	protected Rectangle bounds;
	protected MapProjection projection;

	/**
	 * initiallizes the dimensions of the <code>Grid2D</code>
	 *	object.
	 * @param width the first dimension of the <code>Grid2D</code>
	 * @param height the second dimension of the <code>Grid2D</code>
	 * @param projection <code>MapProjection</code> for this grid, or <code>null</code>.
	 */
	protected Grid2D(int width, int height,
			MapProjection projection) {
		this( new Rectangle(0, 0, width, height),
			projection);
	}
	protected Grid2D(Rectangle bounds,
			MapProjection projection) {
		if( projection==null ) this.projection = new IdentityProjection();
		else this.projection = projection;
		this.bounds = bounds;
	}

	public int[] getDimensions() { 
		return new int[] {bounds.width, bounds.height}; 
	}

	public Rectangle getBounds() {
		return (Rectangle)bounds.clone();
	}

	public MapProjection getProjection() {
		return projection;
	}
	public boolean contains( int x, int y) {
		return !(x<bounds.x 
			|| x>=bounds.x+bounds.width 
			|| y<bounds.y 
			|| y>=bounds.y+bounds.height );
	}
	public boolean contains( double x, double y) {
		return !(x<bounds.x 
			|| x>bounds.x+bounds.width-1 
			|| y<bounds.y 
			|| y>bounds.y+bounds.height-1 );
	}
	public double valueAt(int[] r) {
		return valueAt( r[0], r[1] );
	}
	public abstract double valueAt( int x, int y);

	public double valueAt( double x, double y ) {
		return Interpolate.bicubic(this, x, y);
	}

	public void setValue(int[] r, double val) {
		setValue(r[0], r[1], val);
	}

	public abstract void setValue( int x, int y, double val );

	public static class Double extends Grid2D {
		protected double[] grid;
		public final static double NaN = java.lang.Double.NaN;
		public Double( Rectangle bounds,
				MapProjection projection ) {
			super( bounds, projection );
			grid = new double[bounds.width*bounds.height];
			for( int k=0 ; k<grid.length ; k++ ) grid[k] = NaN;
		}
		public double valueAt( int x, int y) {
			if( !contains(x, y) ) return NaN;
			return grid[x-bounds.x + bounds.width*(y-bounds.y)];
		}
		public void setValue( int x, int y, double val ) {
			if( !contains(x, y) ) throw new ArrayIndexOutOfBoundsException();
			grid[x-bounds.x + bounds.width*(y-bounds.y)] = val;
		}
	}
	public static class Float extends Grid2D {
		public final static float NaN = java.lang.Float.NaN;
		protected float[] grid;
		public Float( Rectangle bounds,
				MapProjection projection ) {
			super( bounds, projection );
			grid = new float[bounds.width*bounds.height];
			for( int k=0 ; k<grid.length ; k++ ) grid[k] = NaN;
		}
		public double valueAt( int x, int y) {
			if( !contains(x, y) ) return Double.NaN;
			return (double)grid[x-bounds.x + bounds.width*(y-bounds.y)];
		}
		public float floatValue( int x, int y) {
			if( !contains(x, y) ) return NaN;
			return grid[x-bounds.x + bounds.width*(y-bounds.y)];
		}
		public void setValue( int x, int y, double val ) {
			setValue( x, y, (float)val);
		}
		public void setValue( int x, int y, float val ) {
			if( !contains(x, y) ) throw new ArrayIndexOutOfBoundsException();
			grid[x-bounds.x + bounds.width*(y-bounds.y)] = val;
		}
	}
	public static class Short extends Grid2D {
		public final static short NaN = -32768;
		protected short[] grid;
		public Short( Rectangle bounds,
				MapProjection projection ) {
			super( bounds, projection );
			grid = new short[bounds.width*bounds.height];
			for( int k=0 ; k<grid.length ; k++ ) grid[k] = NaN;
		}
		public double valueAt( int x, int y) {
			if( !contains(x, y) ) return Double.NaN;
			return (double)grid[x-bounds.x + bounds.width*(y-bounds.y)];
		}
		public short shortValue(int x, int y) {
			if( !contains(x, y) ) return NaN;
			return grid[x-bounds.x + bounds.width*(y-bounds.y)];
		}
		public void setValue( int x, int y, double val ) {
			setValue( x, y, (short)Math.rint(val));
		}
		public void setValue( int x, int y, short val ) {
			if( !contains(x, y) ) throw new ArrayIndexOutOfBoundsException();
			grid[x-bounds.x + bounds.width*(y-bounds.y)] = val;
		}
	}
}
