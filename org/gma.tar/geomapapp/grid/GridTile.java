package org.geomapapp.grid;

import org.geomapapp.proj.*;

public abstract class GridTile extends Grid2D {
	java.awt.Rectangle bounds;
	public GridTile( MapProjection proj,
			int x0,
			int y0,
			int size)
		super( size, size, proj,
			new java.awt.geom.AffineProjection(
				1., 0., 1., 0., -(double)x0, -(double)y0) );
		bounds = new java.awt.Rectangle(x0, y0, size, size);
	}
	public 
