package org.geomapapp.grid;

import org.geomapapp.proj.MapProjection;

public abstract interface GridServer {
	public abstract MapProjection getProjection();
	public abstract double valueAt( int x, int y );
	public abstract void setValue(int x, int y, double val);
	public abstract int getGridSize();
	public abstract GridTile getTile(int x, int y);
}
