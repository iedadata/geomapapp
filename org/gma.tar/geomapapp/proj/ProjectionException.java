package haxby.proj;

public class ProjectionException extends Exception {
	public ProjectionException() {
		super();
	}
	public ProjectionException(String s) {
		super(s);
	}
}
