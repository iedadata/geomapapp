package org.geomapapp.proj;

import noaa.coastwatch.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CWFProj implements ActionListener {
	JFrame frame;
	JComboBox systems;
	JComboBox datums;
	JComboBox zones;
	JTextField[] dim;
	JTextField[] pixelDim;
	JTextField[] center;
	JTextArea info;
	double[] params;
	public CWFProj() {
		systems = new JComboBox( GCTP.PROJECTION_NAMES );
		datums = new JComboBox( GCTP.SPHEROID_NAMES );
		String[] UTMzones = new String[31];
		for( int k=0 ; k<31 ; k++) {
			UTMzones[k] = Integer.toString(k);
		}
		zones = new JComboBox( UTMzones );
		zones.setSelectedIndex(0);
		systems.setSelectedIndex(0);
		datums.setSelectedIndex(0);
		dim = new JTextField[2];
		pixelDim = new JTextField[2];
		center = new JTextField[2];
		dim[0] = new JTextField("1000");
		dim[1] = new JTextField("1000");
		pixelDim[0] = new JTextField("10000");
		pixelDim[1] = new JTextField("10000");
		center[0] = new JTextField("0");
		center[1] = new JTextField("0");
		systems.addActionListener( this );
		datums.addActionListener( this );
		zones.addActionListener( this );
		dim[0].addActionListener( this );
		dim[1].addActionListener( this );
		pixelDim[0].addActionListener( this );
		pixelDim[1].addActionListener( this );
		center[0].addActionListener( this );
		center[1].addActionListener( this );
		JPanel panel1 = new JPanel( new GridLayout( 3, 2 ) );
		panel1.add( new JLabel("projection") );
		panel1.add( systems );
		panel1.add( new JLabel("spheroid") );
		panel1.add( datums );
		panel1.add( new JLabel("zone") );
		panel1.add( zones );
		JPanel panel2 = new JPanel( new GridLayout( 2, 6 ) );
		panel2.add( new JLabel("lat 1",10) );
		panel2.add( new JLabel("lat 2") );
		panel2.add( new JLabel("dx") );
		panel2.add( new JLabel("dy") );
		panel2.add( new JLabel("lat") );
		panel2.add( new JLabel("lon") );
		panel2.add( dim[0] );
		panel2.add( dim[1] );
		panel2.add( pixelDim[0] );
		panel2.add( pixelDim[1] );
		panel2.add( center[0] );
		panel2.add( center[1] );
		JPanel panel3 = new JPanel( new BorderLayout() );
		panel3.add( panel1, "West");
		panel3.add( panel2, "East");
		info = new JTextArea("info");
		frame = new JFrame( "CWF Projections");
		frame.setDefaultCloseOperation( frame.EXIT_ON_CLOSE );
		frame.getContentPane().add( panel3, "North");
		frame.getContentPane().add( info, "Center");
		frame.pack();
		frame.show();
	}
	public void actionPerformed(ActionEvent evt ) {
		project();
	}
	void project() {
		params = new double[15];
		MapProjection proj = null;
		EarthLocation loc = new EarthLocation( Double.parseDouble(center[0].getText()),
						Double.parseDouble(center[1].getText()));
		try {
			proj = new MapProjection( 
				systems.getSelectedIndex(),
				zones.getSelectedIndex(),
				params,
				datums.getSelectedIndex(),
				new int[] {  Integer.parseInt(dim[0].getText()),
						Integer.parseInt(dim[1].getText())
					},
				loc,
				new double[] {  Double.parseDouble(pixelDim[0].getText()),
						Double.parseDouble(pixelDim[1].getText())
					} 
				);
		} catch(Exception ex) {
			ex.printStackTrace();
			return;
		}
		double[] p = proj.transform( loc ).getCoords();
		info.setText( proj.describe() );
		double[] params = proj.getParameters();
		info.append( "\n"+ p[0] +"\t"+ p[1] );

		DataLocation d = new DataLocation( new double[] {0., 0.} );
		p = proj.transform(d).getCoords();
		info.append( "\n"+ p[0] +"\t"+ p[1] );

		GCTP.Requirements req = GCTP.getRequirements( systems.getSelectedIndex() )[0];
		int n = req.getParameters();
		for( int k=0 ; k<15 ; k++) {
			info.append( "\n"+ k +"\t"+ params[k] +"\t"+ req.isRequired(k) 
					+"\t"+ req.getUnits(k) +"\t"+ req.getDescription(k) );
		}
		info.invalidate();
		frame.pack();
		info.repaint();
	}
	public static void main( String[] args ) {
		new CWFProj();
	}
}
