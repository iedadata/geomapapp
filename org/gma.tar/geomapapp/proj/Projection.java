package haxby.proj;

import java.awt.geom.Point2D;

/** 
* An interface that defines methods used by projection objects
* Normally used for translating points from (to) geographics coordinates,
* (longitude, latitude) to (from) map coordinates (x, y).
* @author Bill Haxby
*/
public abstract interface Projection extends java.io.Serializable {
	/**
	* Sphere of constant radius 6370997 meters
	*/
	public static final int SPHERE = 0;
	
	/**
	* Clarke, 1866 ellipsoid.
	*/
	public static final int CLARKE_1866 = 1;
	
	/**
	* wgs-84 ellipsoid.
	*/
	public static final int WGS84 = 2;
	public static final int NORTH = 1;
	public static final int SOUTH = 2;
	public static final double[][] AE_AP = { 
			{ 6370997,	6370997 },
			{ 6378206.4, 	6356583.8 },		// clarke, 1866
			{ 6378137.,	6356752.3 }		// wgs84
			};
	/**	 
		Gets the reference coordinates of the two map coordinates.
		@param mapX Map's X coordinate.
		@param mapY Map's Y coordinate.
		@return the reference coordinates of a mapped point
	*/
	public Point2D getRefXY(double mapX, double mapY);
	
	/**
	 	Gets the reference point of Map coordinates.
	 	@param mapXY the Map point to convert.
		@return the reference coordinates of a mapped point
	*/
	public Point2D getRefXY(Point2D mapXY);
	
	/**
		Gets the Map coordinates of a reference point..
		@param refX the Latitude to convert.		
		@param refY the Longitude to convert.		
		@return the map coordinates of a reference point
	*/
	public Point2D getMapXY(double refX, double refY);
	
	/**
		Gets the Map coordinates of a reference.
		@param refXY the refence point to convert.		
		@return the map coordinates of a reference point
	*/
	public Point2D getMapXY(Point2D refXY);
	
	/**
		Checks if the the projection is cylindrical.
		@return true if the projection is cylindrical, i.e. if 
		<PRE>
			mapX = f(refX) 
		 and 	mapY = f(refY)
		</PRE>	
	*/
	public boolean isCylindrical();
	
	/**
		Gets if the projection is conic.
		@return true if the projection is conic.
	*/
	public boolean isConic();
	
	/**
		Compares if the sent Object is equal to the current Object.
		@return true if the tow objects are equal.
	*/
	public boolean equals(Object obj);
}
