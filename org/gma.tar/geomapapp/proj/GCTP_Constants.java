package org.geomapapp.proj;

public interface GCTP_Constants {

/* Semi-Major axis of supported Spheroids */
public final static double[] major = {
		6378206.4,		/* 0: Clarke 1866 (default) */
		6378249.145,		/* 1: Clarke 1880 */
		6377397.155,		/* 2: Bessel */
		6378157.5,		/* 3: International 1967 */
		6378388.0,		/* 4: International 1909 */
		6378135.0,		/* 5: WGS 72 */
		6377276.3452,		/* 6: Everest */
		6378145.0,		/* 7: WGS 66 */
                6378137.0,		/* 8: GRS 1980 */
		6377563.396,		/* 9: Airy */
		6377304.063,		/* 10: Modified Everest */
		6377340.189,		/* 11: Modified Airy */
                6378137.0,		/* 12: WGS 84 */
		6378155.0,		/* 13: Southeast Asia */
		6378160.0,		/* 14: Australian National */
		6378245.0,		/* 15: Krassovsky */
                6378270.0,		/* 16: Hough */
		6378166.0,		/* 17: Mercury 1960 */
		6378150.0,		/* 18: Modified Mercury 1968 */
		6370997.0,		/* 19: Sphere of Radius 6370997 meters*/
	};

	/* Semi-Minor axis of supported Spheroids */
public final static double[] minor = {
		6356583.8,		/* 0: Clarke 1866 (default) */
		6356514.86955,		/* 1: Clarke 1880 */
		6356078.96284,		/* 2: Bessel */
		6356772.2,		/* 3: International 1967 */
                6356911.94613,		/* 4: International 1909 */
		6356750.519915,		/* 5: WGS 72 */
		6356075.4133,		/* 6: Everest */
                6356759.769356,		/* 7: WGS 66 */
		6356752.31414,		/* 8: GRS 1980 */
		6356256.91,		/* 9: Airy */
                6356103.039,		/* 10: Modified Everest */
		6356034.448,		/* 11: Modified Airy */
		6356752.314245,		/* 12: WGS 84 */
                6356773.3205,		/* 13: Southeast Asia */
		6356774.719,		/* 14: Australian National */
		6356863.0188,		/* 15: Krassovsky */
                6356794.343479,		/* 16: Hough */
		6356784.283666,		/* 17: Mercury 1960 */
		6356768.337303,		/* 18: Modified Mercury 1968 */
                6370997.0,		/* 19: Sphere of Radius 6370997 meters*/
	};

  // Projection constants
  // --------------------
  /** Geographic projection code. */
  public static final int GEO        = 0;

  /** Universal Transverse Mercator projection code. */
  public static final int UTM        = 1;

  /** State Plane Coordinates projection code. */
  public static final int SPCS       = 2;

  /** Albers Conical Equal Area projection code. */
  public static final int ALBERS     = 3;

  /** Lambert Conformal Conic projection code. */
  public static final int LAMCC      = 4;

  /** Mercator projection code. */
  public static final int MERCAT     = 5;

  /** Polar Stereographic projection code. */
  public static final int PS         = 6;

  /** Polyconic projection code. */
  public static final int POLYC      = 7;

  /** Equidistant Conic projection code. */
  public static final int EQUIDC     = 8;

  /** Transverse Mercator projection code. */
  public static final int TM         = 9;

  /** Stereographic projection code. */
  public static final int STEREO     = 10;

  /** Lambert Azimuthal Equal Area projection code. */
  public static final int LAMAZ      = 11;

  /** Azimuthal Equidistant projection code. */
  public static final int AZMEQD     = 12;

  /** Gnomonic projection code. */
  public static final int GNOMON     = 13;

  /** Orthographic projection code. */
  public static final int ORTHO      = 14;

  /** General Vertical Near-Side Perspective projection code. */
  public static final int GVNSP      = 15;

  /** Sinusiodal projection code. */
  public static final int SNSOID     = 16;

  /** Equirectangular projection code. */
  public static final int EQRECT     = 17;

  /** Miller Cylindrical projection code. */
  public static final int MILLER     = 18;

  /** Van der Grinten projection code. */
  public static final int VGRINT     = 19;

  /** Hotine Oblique Mercator projection code. */
  public static final int HOM        = 20;

  /** Robinson projection code. */
  public static final int ROBIN      = 21;

  /** Space Oblique Mercator (SOM) projection code. */
  public static final int SOM        = 22;

  /** Alaska Conformal projection code. */
  public static final int ALASKA     = 23;

  /** Interrupted Goode Homolosine projection code. */
  public static final int GOOD       = 24;

  /** Mollweide projection code. */
  public static final int MOLL       = 25;

  /** Interrupted Mollweide projection code. */
  public static final int IMOLL      = 26;

  /** Hammer projection code. */
  public static final int HAMMER     = 27;

  /** Wagner IV projection code. */
  public static final int WAGIV      = 28;

  /** Wagner VII projection code. */
  public static final int WAGVII     = 29;

  /** Oblated Equal Area projection code. */
  public static final int OBEQA      = 30;

  /** User defined projection code. */
  public static final int USDEF      = 99;

  /** The total number of projection codes. */
  public static final int MAX_PROJECTIONS = 31;

  /** The list of projection code names. */
  public static final String[] PROJECTION_NAMES = {
    "Geographic",
    "Universal Transverse Mercator",
    "State Plane Coordinates",
    "Albers Conical Equal Area",
    "Lambert Conformal Conic",
    "Mercator",
    "Polar Stereographic",
    "Polyconic",
    "Equidistant Conic",
    "Transverse Mercator",
    "Stereographic",
    "Lambert Azimuthal Equal Area",
    "Azimuthal Equidistant",
    "Gnomonic",
    "Orthographic",
    "General Vertical Near-side Perspective",
    "Sinusiodal",
    "Equirectangular",
    "Miller Cylindrical",
    "Van der Grinten",
    "Hotine Oblique Mercator",
    "Robinson",
    "Space Oblique Mercator",
    "Alaska Conformal",
    "Interrupted Goode Homolosine",
    "Mollweide",
    "Interrupted Mollweide",
    "Hammer",
    "Wagner IV",
    "Wagner VII",
    "Oblated Equal Area"
  };

  // Units constants
  // ---------------
  /** Radians units code. */
  public static final int RADIAN      = 0;

  /** US Feet units code. */
  public static final int FEET        = 1;

  /** Meters units code. */
  public static final int METER       = 2;

  /** Arc Seconds units code. */
  public static final int SECOND      = 3;

  /** Decimal degrees units code. */
  public static final int DEGREE      = 4;

  /** International Feet units code. */
  public static final int INT_FEET    = 5;

  /**
   * State Plane table units code. The STPLN_TABLE unit value is
   * specifically used for State Plane -- if units equals STPLN_TABLE
   * and Datum is NAD83 -- actual units are retrieved from a table
   * according to the zone.  If Datum is NAD27 -- actual units will be
   * feet.  An error will occur with this unit if the projection is
   * not State Plane.
   */
  public static final int STPLN_TABLE = 6;

  // Spheroid constants
  // ------------------
  /** Clarke 1866 (default) spheroid code. */
  public static final int CLARKE1866   = 0;

  /** Clarke 1880 spheroid code. */
  public static final int CLARKE1880   = 1;

  /** Bessel spheroid code. */
  public static final int BESSEL       = 2;

  /** International 1967 spheroid code. */
  public static final int INT1967      = 3;

  /** International 1909 spheroid code. */
  public static final int INT1909      = 4;

  /** WGS 72 spheroid code. */
  public static final int WGS72        = 5;

  /** Everest spheroid code. */
  public static final int EVEREST      = 6;

  /** WGS 66 spheroid code. */
  public static final int WGS66        = 7;

  /** GRS 1980 spheroid code. */
  public static final int GRS1980      = 8;

  /** Airy spheroid code. */
  public static final int AIRY         = 9;

  /** Modified Everest spheroid code. */
  public static final int MOD_EVEREST  = 10;

  /** Modified Airy spheroid code. */
  public static final int MOD_AIRY     = 11;

  /** WGS 84 spheroid code. */
  public static final int WGS84        = 12;

  /** SouthEast Asia spheroid code. */
  public static final int SE_ASIA      = 13;

  /** Austrialian National spheroid code. */
  public static final int AUS_NAT      = 14;

  /** Krassovsky spheroid code. */
  public static final int KRASS        = 15;

  /** Hough spheroid code. */
  public static final int HOUGH        = 16;

  /** Mercury 1960 spheroid code. */
  public static final int MERCURY1960  = 17;

  /** Modified Mercury 1968 spheroid code. */
  public static final int MOD_MER1968  = 18;

  /** Sphere of radius 6,370,997 metres spheroid code. */
  public static final int SPHERE       = 19;

  /** The total number of spheroid codes. */
  public static final int MAX_SPHEROIDS = 20;

  /** The list of spheroid code names. */
  public static final String[] SPHEROID_NAMES = {
    "Clarke 1866",
    "Clarke 1880",
    "Bessel",
    "International 1967",
    "International 1909",
    "WGS 72",
    "Everest",
    "WGS 66",
    "GRS 1980",
    "Airy",
    "Modified Everest",
    "Modified Airy",
    "WGS 84",
    "SouthEast Asia",
    "Austrialian National",
    "Krassovsky",
    "Hough",
    "Mercury 1960",
    "Modified Mercury 1968",
    "Sphere of radius 6370997 m"
  };
}
