package org.geomapapp.util;

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;

public class XBIcon implements Icon {
	BufferedImage image;
	boolean selected;
	public XBIcon(BufferedImage image, boolean selected) {
		this.image = image;
		this.selected = selected;
	}
	public int getIconWidth() {
		return image.getWidth()+2;
	}
	public int getIconHeight() {
		return image.getHeight()+2;
	}
	public void setImage(BufferedImage image) {
		this.image=image;
	}
	public BufferedImage getImage() {
		return image;
	}
	public void paintIcon(Component c, Graphics g, int x, int y) {
		SimpleBorder border = SimpleBorder.getBorder();
		border.setSelected(selected);
		border.paintBorder(c, g, x, y, getIconWidth(), getIconHeight());
		g.drawImage(image, x+1,y+1, c);
	}
}
