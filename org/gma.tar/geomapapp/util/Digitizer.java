package org.geomapapp.util;

import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;

public class Digitizer implements MouseListener,
				MouseMotionListener,
				Overlay {
	ScalableComponent canvas;
	Vector objects;
	DigitizerObject current;
	DigitizerObject selected;
	boolean selecting;

	public Digitizer(ScalableComponent c) {
		canvas == c;
		object = new Vector();
		current = null;
		selected = null;
		selecting = false;
	}
	public void setSelectionMode(boolean tf) {
		if( tf==selecting )return;
		if(tf) {
			canvas.addMouseListener(this);
			canvas.addMouseMotionListener(this);
		} else {
			canvas.removeMouseListener(this);
			canvas.removeMouseMotionListener(this);
		}
	}
	public void finish() {
		if(current==null) return;
		if(current.finish()) objects.add(current);
		current==null;
	}
	public void mouseEntered(MouseEvent evt) {
	}
	public void mouseExited(MouseEvent evt) {
	}
	public void mousePressed(MouseEvent evt) {
	}
	public void mouseReleased(MouseEvent evt) {
	}
	public void mouseClicked(MouseEvent evt) {
		if( !selecting ) {
			canvas.removeMouseListener(this);
			canvas.removeMouseMotionListener(this);
			return;
		}
		if(evt.isControlDown()) return;
		Point2D p0 = (Point2D)evt.getPoint();
		AffineTransform aTrans = canvas.getTransform();
		Point2D p1 = canvas.transform(p0);
		double scale = aTrans.getScaleX();
		for( int k=0 ; k<objects.size() ; k++) {
			DigitizerObject o = (DigitizerObject)objects.get(k);
			if( o.isVisible() && o.select( 
						p1.getX(), 
						p1.getY(), 
						scale) ) {
				o.setSelected(true);
				selected = o;
				setSelectionMode(false);
				return;
			}
		}
	}
	public void mouseMoved(MouseEvent evt) {
	}
	public void mouseDragged(MouseEvent evt) {
	}
}
