package org.geomapapp.util;

import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class DigitizeTools 
		implements ActionListener,
			KeyListener {
	Digitizer dig;
	JToggleButton[] buttons;
