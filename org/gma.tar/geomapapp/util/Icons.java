package org.geomapapp.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;

public class Icons {
	public static int SELECT = 0;
	public static int ZOOM_IN = 1;
	public static int ZOOM_OUT = 2;
	public static int FORWARD = 3;
	public static int BACK = 4;
	public static int GRID = 5;
	public static int HORIZONTAL = 6;
	public static int VERTICAL = 7;
	public static int MOVE = 8;
	public static int ROTATE = 9;
	public static int SCALE = 10;
	public static int SAVE = 11;
	public static int WIDER = 12;
	public static int NARROWER = 13;

	public static int MASK = 3;
	public static int CONTOUR = 5;
	public static int GRATICULE = 6;
//	public static int FORWARD = 7;
	public static int REVERSE = 8;
	public static int SEGMENTS = 12;
	public static int DEPTH = 13;
	public static int ANNOTATION = 14;
	public static int ROTATE_270 = 15;
	public static int ROTATE_90 = 16;
	public static int NEXT = 17;
//	public static int BACK = 18;
	public static int FOCUS = 32;
	public static int POSITIVE = 33;
	public static int NEGATIVE = 34;
	public static int GRAY = 35;
	static XBIcon[][] icons = new XBIcon[14][2];
	static String[] names = new String[] {
				"select.png",
				"zoom_in.png",
				"zoom_out.png",
				"forward.png",
				"back.png",
				"grid.png",
				"horizontal.png",
				"vertical.png",
				"move.png",
				"rotate.png",
				"scale.png",
				"save.png",
				"wider.png",
				"narrower.png"
			};
	static int[] rgb = { 0, 0xff000000, 0xffffffff, 0xffff0000 };
	static ClassLoader loader = null;
	static XBIcon[] defaultIcon = new XBIcon[2];
	public static XBIcon getDefaultIcon(boolean selected) {
		int i = selected ? 1 : 0;
		if( defaultIcon[i] != null) return defaultIcon[i];
		int i1 = (i+1)%2;
		if( defaultIcon[i1] != null) {
			defaultIcon[i] = new XBIcon( defaultIcon[i1].getImage(), selected);
			return defaultIcon[i];
		}
		BufferedImage im = new BufferedImage(22, 22, 
				BufferedImage.TYPE_INT_ARGB);
		int black = 0xff000000;
		for( int y=0 ; y<22 ; y++) {
			for( int x=0 ; x<22 ; x++) {
				im.setRGB(x,y,0);
			}
		}
		for( int y=6 ; y<16 ; y++ ) {
			im.setRGB( 6, y, black );
			im.setRGB( 15, y, black );
			im.setRGB( y, 6, black );
			im.setRGB( y, 15, black );
		}
		defaultIcon[i] = new XBIcon(im, selected);
		return defaultIcon[i];
	}
	public static XBIcon getIcon(int which, boolean selected) {
		if( which<0 || which>=icons.length ) return getDefaultIcon(selected);
		int i = selected ? 1 : 0;
		if( icons[which][i]!=null )return icons[which][i];
		int i1 = (i+1)%2;
		if( icons[which][i1]!=null ) {
			icons[which][i] = new XBIcon(icons[which][i1].getImage(), selected);
			return icons[which][i];
		}

		try {
			if( loader==null ) {
				loader = org.geomapapp.util.Icons.class.getClassLoader();
			}
			String path = "org/geomapapp/util/icons/" +names[which];
			java.net.URL url = loader.getResource(path);
			BufferedImage im = ImageIO.read(url);
			icons[which][i] = new XBIcon(im, selected);
		} catch(Exception ex) {
			return getDefaultIcon(selected);
		}
		return icons[which][i];
	}
	public static void main(String[] args) {
		JFrame frame = new JFrame("Icons");
		Box box = Box.createHorizontalBox();
		JToggleButton tb;
		for(int k=-1 ; k<icons.length ; k++) {
			tb = new JToggleButton();
			tb.setIcon( getIcon(k, false) );
			tb.setSelectedIcon( getIcon(k, true) );
			tb.setBorder(null);
			box.add(tb);
		}
		frame.getContentPane().add(box,"North");
		frame.pack();
		frame.show();
		frame.setDefaultCloseOperation( frame.EXIT_ON_CLOSE);
	}
}
