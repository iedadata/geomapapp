package org.geomapapp.util;

import haxby.map.*;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;

public class XYGraph extends JComponent
			implements Zoomable,
				Scrollable {
	XYPoints xy;
	int dataIndex;
	Axes axes = null;
	double width;
	double height;
	double[] xRange, yRange;
	double xScale, yScale;
	double zoom;
	JScrollPane scPane = null;
	boolean tracksWidth, tracksHeight;
	public XYGraph( XYPoints pts, int dataIndex ) {
		setPoints( pts, dataIndex );
		zoom = 1.;
		tracksWidth = tracksHeight = false;
	}
	public void setPoints( XYPoints pts, int dataIndex ) {
		xy = pts;
		this.dataIndex = dataIndex;
		xRange = xy.getXRange( dataIndex );
		yRange = xy.getYRange( dataIndex );
		xScale = xy.getPreferredXScale( dataIndex );
		yScale = xy.getPreferredYScale( dataIndex );
		width = (xRange[1] - xRange[0]) *xScale;
		if(width<0.) {
			width = -width;
			xScale = -xScale;
		}
		height = (yRange[0] - yRange[1]) *yScale;
		if(height<0.) {
			height = -height;
			yScale = -yScale;
		}
		int sides = Axes.LEFT | Axes.BOTTOM |Axes.RIGHT | Axes.TOP;
		if( axes != null ) sides = axes.sides;
		axes = new Axes( xy, dataIndex,  sides);
		setBackground( Color.white );
	}
	public void setAxesSides( int sides ) {
		axes.setSides( sides);
		if( isVisible() ) repaint();
	}
	public void setZoom(double z) {
		zoom = z;
	}
	public double getZoom() {
		return zoom;
	}
// methods implementing Zoomable
	public void zoomIn( Point p ) {
		doZoom( p, 2. );
	}
	public void zoomOut( Point p ) {
		doZoom( p, .5 );
	}
	public void zoomTo( Rectangle r ) {
	}
	public void setRect( Rectangle r ) {
	}
	public void setXY( Point p ) {
	}
	void doZoom( Point p, double factor ) {
		if( scPane == null || ( tracksWidth && tracksHeight ))return;
		Insets ins = axes.getInsets();
		Rectangle rect = getVisibleRect();
		double x = (double)(p.x-ins.left) / zoom;
		double y = (double)(p.y-ins.top) / zoom;
		double w = (double) (rect.width - ins.left - ins.right);
		double h = (double) (rect.height - ins.top - ins.bottom);
		zoom *= factor;
		int newX = (int) (x*zoom - w*.5d);
		int newY = (int) (y*zoom - h*.5d);
		invalidate();
		scPane.validate();
		JScrollBar sb;
		if(!tracksWidth) {
			sb = scPane.getHorizontalScrollBar();
			sb.setValue(newX);
		}
		if(!tracksHeight) {
			sb = scPane.getVerticalScrollBar();
			sb.setValue(newY);
		}
		revalidate();
	}
// methods implementing Scrollable
	public Dimension getPreferredScrollableViewportSize() {
		return getPreferredSize();
	}
	public int getScrollableUnitIncrement(Rectangle visibleRect,
					int orientation,
					int direction) {
		return 10;
	}
	public int getScrollableBlockIncrement(Rectangle visibleRect,
					int orientation,
					int direction) {
		Insets ins = axes.getInsets();
		if( orientation==SwingConstants.HORIZONTAL ) {
			return (visibleRect.width-ins.left-ins.right) / 2;
		} else {
			return (visibleRect.height-ins.top-ins.bottom) / 2;
		}
	}
	public boolean getScrollableTracksViewportWidth() {
		return tracksWidth;
	}
	public boolean getScrollableTracksViewportHeight() {
		return tracksHeight;
	}
	public void setScrollableTracksViewportWidth( boolean tf ) {
		tracksWidth = tf;
	}
	public void setScrollableTracksViewportHeight( boolean tf ) {
		tracksHeight = tf;
	}
	public void addNotify() {
		super.addNotify();
		Container c = getParent();
		while( !( c instanceof JScrollPane) ) {
			c = c.getParent();
			if( c==null ) {
				scPane=null;
				return;
			}
		}
		scPane = (JScrollPane)c;
	}
	public double getXAt( Point2D p ) {
		Insets insets = axes.getInsets();
		Rectangle r = getVisibleRect();
		double w = (double)(r.width - insets.left - insets.right);
		if( tracksWidth  || scPane==null) {
			return xRange[0] + (xRange[1]-xRange[0])*(p.getX()-(double)insets.left)/w;
		} else {
			return xRange[0] + (p.getX()-(double)insets.left) / (xScale*zoom);
		}
	}
	public double getYAt( Point2D p ) {
		Insets insets = axes.getInsets();
		Rectangle r = getVisibleRect();
		double h = (double)(r.height - insets.top - insets.bottom);
		if( tracksHeight  || scPane==null) {
			return yRange[1] + (yRange[1]-yRange[0])*(p.getY()-(double)insets.top)/h;
		} else {
			return yRange[1] + (p.getY()-(double)insets.top) / (yScale*zoom);
		}
	}
	public void removeNotify() {
		super.removeNotify();
		scPane = null;
	}
	public Dimension getPreferredSize() {
		Insets ins = axes.getInsets();
		int w = ins.left + ins.right + (int)Math.ceil(width);
		int h = ins.top + ins.bottom + (int)Math.ceil(height);
		if( !tracksWidth ) {
			w = ins.left + ins.right + (int)Math.ceil( zoom*width);
		}
		if( !tracksHeight ) {
			h = ins.top + ins.bottom + (int)Math.ceil( zoom*height);
		}
		return new Dimension( w, h );
	}
	public void paint( Graphics graphics ) {
		Dimension dim = getPreferredSize();
		Graphics2D g = (Graphics2D) graphics;
		Rectangle r = getVisibleRect();
		g.setColor(Color.white);
		g.fill( r );
		Rectangle2D.Double bounds = new Rectangle2D.Double();
		Insets ins = axes.getInsets();
		double w = (double)(r.width - ins.left - ins.right);
		double h = (double)(r.height - ins.top - ins.bottom);
		double sX, sY;
		if( tracksWidth  || scPane==null) {
			bounds.x = xRange[0];
			bounds.width = xRange[1]-xRange[0];
			sX = w / bounds.width;
		} else {
			bounds.x = xRange[0] + (double)(r.x) / (xScale*zoom);
			bounds.width = w / (xScale*zoom);
			sX = xScale*zoom;
		}
		if( tracksHeight || scPane==null ) {
			bounds.y = yRange[1];
			bounds.height = yRange[0]-yRange[1];
			sY = h / bounds.height;
		} else {
			bounds.y = yRange[1] + (double)(r.y) / (yScale*zoom);
			bounds.height = (double)(r.height - ins.top - ins.bottom) / (yScale*zoom);
			sY = yScale*zoom;
		}
	//	System.out.println( "bounds:\t"+bounds.x 
	//			+"\t"+ bounds.y 
	//			+"\t"+ bounds.width 
	//			+"\t"+ bounds.height
	//			+"\nscales\t" + sX +"\t"+ sY);
		axes.drawAxes( g, bounds, r );
		g.clipRect( r.x+ins.left, r.y+ins.top, 
			r.width-ins.left-ins.right, 
			r.height-ins.top-ins.bottom );
		g.translate( r.x+ins.left, r.y+ins.top );
		xy.plotXY( g, bounds, sX, sY, dataIndex );
	}
}
