package org.geomapapp.util;

// import haxby.image.*;
import org.geomapapp.image.*;

import java.awt.*;
import java.beans.*;
import javax.swing.*;
import java.awt.image.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.imageio.*;
import java.io.*;

public class ImageComponent extends ScalableComponent {
	protected BufferedImage image = null;
	JFileChooser chooser = null;
	BalancePanel balance=null;
	JDialog colorDialog=null;
	protected File file=null;
	public ImageComponent() {
		setLayout(null);
		width = 800;
		height = 600;
	}
	public ImageComponent(JFileChooser chooser) throws IOException {
		this();
		this.chooser = chooser;
	}
	public ImageComponent(File file) throws IOException {
		this();
		chooser = null;
		open(file);
	}
	public void addNotify() {
		super.addNotify();
		initBalance();
	}
	void initBalance() {
		if(balance!=null) return;
		balance = new BalancePanel();
		balance.addPropertyChangeListener( new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if( evt.getPropertyName().equals("BRIGHTNESS") ) {
					repaint();
				} else if( evt.getPropertyName().equals("APPLY_MODS")) {
					apply();
				}
			}
		});
		colorDialog = new JDialog( (JFrame)getTopLevelAncestor(), "ColorBalance");
		colorDialog.getContentPane().add( balance );
		colorDialog.pack();
	}
	public void showColorDialog() {
		if(  colorDialog==null )return;
		colorDialog.show();
	}
	public void open() throws IOException {
		if( chooser==null ) chooser = new JFileChooser(
				System.getProperty("user.dir"));
		Container c = getTopLevelAncestor();
		int ok = chooser.showOpenDialog(c);
		if( ok==chooser.CANCEL_OPTION ) return;
		open( chooser.getSelectedFile() );
	}
	public void open(File file) throws IOException {
		BufferedImage image = ImageIO.read( file );
		if(image==null)return;
		this.image = image;
		width = image.getWidth();
		height = image.getHeight();
		this.file = file;
		repaint();
	}
	public File getFile() {
		return file;
	}
	public void save() throws IOException {
		if( file==null ) return;
		int ok = JOptionPane.showConfirmDialog(
			(JFrame)getTopLevelAncestor(),
			"overwrite "+file.getName()+"?",
			"overwrite?",
			JOptionPane.YES_NO_CANCEL_OPTION);
		if( ok==JOptionPane.CANCEL_OPTION) return;
		if( ok==JOptionPane.NO_OPTION) {
			chooser.setSelectedFile( file);
			ok = chooser.showSaveDialog((JFrame)getTopLevelAncestor());
			if( ok==chooser.CANCEL_OPTION) return;
			file = chooser.getSelectedFile();
		}
		ByteLookupTable lookup = balance.getLookup();
		if(lookup!=null) {
			ok = JOptionPane.showConfirmDialog(
				(JFrame)getTopLevelAncestor(),
				"Apply Color Mods?",
				"select an option",
				JOptionPane.YES_NO_OPTION);
			if( ok==JOptionPane.YES_OPTION ) {
				BufferedImage im = new BufferedImage( width, height, 
						image.TYPE_INT_RGB);
				Graphics2D g = im.createGraphics();
				g.drawImage( image, new LookupOp( lookup, null ), 0, 0);
				image = im;
			}
			balance.reset();
		}
		String type = file.getName().substring(
			file.getName().indexOf(".")+1).toLowerCase();
		if( !type.equals("jpg") && !type.equals("png")) type="jpg";
		ImageIO.write( image, type, file);
	}
	public void paintComponent(Graphics g) {
		if(image==null) return;
		Graphics2D g2 = (Graphics2D) g;
		ByteLookupTable lookup = balance.getLookup();
		if(lookup!=null) {
			g2.transform(getTransform());
			g2.drawImage( image, new LookupOp( lookup, null ), 0, 0);
			g2.setTransform( new AffineTransform());
		} else {
			g2.drawRenderedImage(image, getTransform());
		}
	}
	public void rotate( Point2D center, double angle ) {
		BufferedImage im = new BufferedImage( width, height, image.TYPE_INT_RGB);
		Graphics2D g = im.createGraphics();
		AffineTransform at = new AffineTransform();
		at.rotate( -angle, center.getX(), center.getY() );
		g.drawRenderedImage( image, at);
		image = im;
		repaint();
	}
	public void apply() {
		if( balance==null ) return;
		ByteLookupTable lookup = balance.getLookup();
		if(lookup==null) return;
		int ok = JOptionPane.showConfirmDialog(
			(JFrame)getTopLevelAncestor(),
			"Apply Color Mods?",
			"select an option",
			JOptionPane.YES_NO_OPTION);
		if( ok== JOptionPane.NO_OPTION) return;
		BufferedImage im = new BufferedImage( width, height, 
			image.TYPE_INT_RGB);
		Graphics2D g = im.createGraphics();
		g.drawImage( image, new LookupOp( lookup, null ), 0, 0);
		image = im;
		balance.reset();
	}
}
