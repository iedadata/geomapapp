package org.geomapapp.util;

import java.awt.*;
import javax.swing.*;

public class ColorIcon implements Icon {
	Color color;
	int width, height;
	boolean selected;
	public ColorIcon(int width, int height, Color color, boolean selected) {
		this.color = color;
		this.width = width;
		this.height = height;
		this.selected = selected;
	}
	public ColorIcon(Color color, boolean selected) {
		this( 24, 24, color, selected);
	}
	public int getIconWidth() {
		return width;
	}
	public int getIconHeight() {
		return height;
	}
	public void setColor(Color color) {
		this.color=color;
	}
	public Color getColor() {
		return color;
	}
	public void paintIcon(Component c, Graphics g, int x, int y) {
		SimpleBorder border = SimpleBorder.getBorder();
		border.setSelected( selected);
		border.paintBorder(c, g, x, y, width, height);
		g.setColor(color);
		g.fillRect(x+2, y+2, width-4, height-4);
	}
}
