package org.geomapapp.image;

import org.geomapapp.geom.Perspective3D;

public abstract interface PerspectiveGeometry {
	public abstract Perspective3D getPerspective();
}
