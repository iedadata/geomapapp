package org.geomapapp.image;

import org.geomapapp.util.SimpleBorder;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.MouseInputAdapter;

public class VETool extends JComponent {
	double ve;
	double veStart;
	MouseInputAdapter mouse;
	Point point;
	JPanel panel;
	JTextField veF;
	java.text.NumberFormat fmt;
	public VETool(double ve) {
		this.ve = ve;
		fmt = java.text.NumberFormat.getInstance();
		fmt.setMaximumFractionDigits(2);
		veF = new JTextField( fmt.format(ve));
		mouse = new MouseInputAdapter() {
			public void mousePressed(MouseEvent evt) {
				setStart();
			}
			public void mouseReleased(MouseEvent evt) {
				apply( evt.getPoint(), evt.isShiftDown() );
			}
			public void mouseDragged(MouseEvent evt) {
				drag( evt.getPoint(), evt.isShiftDown() );
			}
		};
		addMouseListener(mouse);
		addMouseMotionListener(mouse);
		point = null;
	}
	void setStart() {
		veStart = ve;
	}
	void drag( Point p, boolean fine) {
		if( !isVisible() ) return;
		if( point==null ) {
			point = p;
			return;
		}
		if( p.y==point.y )return;
		double factor = fine ? 1.004 : 1.02;
		if( p.y>point.y ) {
			for( int y=point.y ; y<=p.y ; y++ ) ve/=factor;
		} else {
			for( int y=point.y ; y>=p.y ; y-- ) ve*=factor;
		}
		point = p;
		repaint();
	}
	public JPanel getPanel() {
		if( panel==null )initPanel();
		return panel;
	}
	void initPanel() {
		veF.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				setVE();
			}
		});
		JPanel input = new JPanel(new GridLayout(0,1));
		input.add(new JLabel("V. E."));
		input.add(veF);
		input.add(new JLabel(""));
		input.add(new JLabel(""));
		SimpleBorder sb = new SimpleBorder();
		setBorder( sb );
		input.setBorder( sb );
		panel  = new JPanel(new GridLayout(1,0));
		panel.add(this);
		panel.add(input);
	}
	void apply(Point p, boolean fine) {
		if( point==null )return;
		double oldVE = ve;
		drag(p, fine);
		point = null;
		synchronized( getTreeLock() ) {
			firePropertyChange("VE_CHANGED", veStart, ve);
		}
	}
	void setVE() {
		try {
			double oldVE = ve;
			double newVE = Double.parseDouble(veF.getText());
			if( ve==newVE )return;
			ve = newVE;
			firePropertyChange("VE_CHANGED", oldVE, ve);
		}catch(Exception ex) {
		}
		repaint();
	}
	public double getVE() {
		return ve;
	}
	public void setVE(double ve) {
		veF.setText( fmt.format(ve) );
		setVE();
	}
	public Dimension getPreferredSize() {
		Insets ins = getInsets();
		Dimension size = new Dimension(100, 100);
		if( ins!=null ) {
			size.width += ins.left + ins.right;
			size.height += ins.top + ins.bottom;
		}
		return size;
	}
	Rectangle getRect() {
		if( !isVisible() ) return null;
		Rectangle r = getVisibleRect();
		Insets ins = getInsets();
		r.x += ins.left;
		r.y += ins.top;
		r.width -= ins.left + ins.right;
		r.height -= ins.top + ins.bottom;
		return r;
	}
	public void paintComponent(Graphics g) {
		if( !isVisible() ) return;
		Graphics2D g2 = (Graphics2D)g;
		AffineTransform at = g2.getTransform();
		Rectangle r = getRect();
		g2.setRenderingHint( RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		double x0 = r.x + r.getWidth()/2.;
		double y0 = r.y + r.getHeight()/2.;
		double size = .9*Math.min( r.getWidth(), r.getHeight());
		Line2D.Double line = new Line2D.Double(x0-.5*size,
						y0+.5*size, 
						x0+.5*size, 
						y0+.5*size);
		g2.draw(line);
		line.x2 = line.x1;
		line.y2 = line.y1-size;
		g2.draw(line);
		if( ve>=1. ) {
			line.x1 = line.x1 + size/ve;
		} else {
			line.y1 = line.y1 - size*ve;
			line.x2 = x0+.5*size;
			line.y2 = y0+.5*size;
		}
		g2.draw(line);
		veF.setText( fmt.format(ve));
	//	String s = fmt.format(ve);
	//	Font font = g.getFont().deriveFont( .2f*(float)size);
	//	g.setFont(font);
	//	g2.translate( x0-size/10., y0-size/4. );
	//	g2.drawString( fmt.format(ve), 0, 0);
	//	g2.setTransform(at);
	}
	public static void main(String[] args) {
		VETool tool = new VETool(1.);
		JFrame frame = new JFrame("test VE");
		frame.getContentPane().add( tool);
		frame.setDefaultCloseOperation( frame.EXIT_ON_CLOSE);
		frame.pack();
		frame.show();
	}
}
