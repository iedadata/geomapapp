package org.geomapapp.image;

import org.geomapapp.util.SimpleBorder;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.TitledBorder;

public class ColorModPanel extends JPanel {
	int rgb;
	int rgb0;
	ColorPane[] panes;
	JSlider transS;
	ColorComponent swatch;
	MouseInputAdapter mouse;
	JPanel resetPanel;
	public ColorModPanel(int rgb, boolean transparency) {
		super( new BorderLayout() );
		if(transparency) {
			transS = new JSlider();
			int val = (rgb>>24)&255;
			val = (255-val)*100/255;
			transS.setValue(val);
			rgb |= 0xff000000;
		}
		rgb0 = rgb;
		setRGB( rgb );
		init();
	}
	public ColorModPanel(int rgb) {
		this(rgb, false);
	}
	void init() {
		if( panes!=null )return;
		JPanel hsbPanel = new JPanel(new GridLayout(1,0,2,2));
		hsbPanel.setBorder(BorderFactory.createTitledBorder(
					null,
					"H-S-B",
					TitledBorder.LEFT,
					TitledBorder.BOTTOM));
		
		panes = new ColorPane[3];
		mouse = new MouseInputAdapter() {
			ColorPane cp =null;
			public void mouseClicked(MouseEvent evt) {
				cp = (ColorPane)evt.getSource();
				setRGB( cp.getRGB(evt.getPoint()) );
			}
			public void mouseReleased(MouseEvent evt) {
				update();
				cp = null;
			}
			public void mouseDragged(MouseEvent evt) {
				if( cp==null || cp==evt.getSource() ) {
					mouseClicked(evt);
				}
			}
		};
		for(int i=0 ; i<3 ; i++) {
			panes[i] = new ColorPane(rgb, i+3);
			panes[i].addMouseListener(mouse);
			panes[i].addMouseMotionListener(mouse);
			hsbPanel.add(panes[i]);
		}
		panes[0].setToolTipText("modify hue");
		panes[1].setToolTipText("modify saturation");
		panes[2].setToolTipText("modify brightness");
		add(hsbPanel, "Center");
		swatch = new ColorComponent(new Color(rgb));
		swatch.setToolTipText("reset color");

		swatch.addMouseListener( new MouseAdapter() {
			public void mouseClicked(MouseEvent evt) {
				reset();
			}
		});
		add(swatch, "South");
		if( transS!=null) {
			transS.setBorder(new TitledBorder("Transparency"));
			add(transS, "North");
		}
	}
	public int getTransparency() {
		if( transS==null ) return 0;
		return (100-transS.getValue())*255/100;
	}
	public void reset() {
		if( rgb==rgb0 )return;
		setRGB( rgb0 );
		update();
	}
	public void update() {
		firePropertyChange("APPLY", 0, rgb);
	}
	public void setDefaultRGB( int rgb ) {
		if( rgb0==rgb )return;
		rgb0 = rgb;
		setRGB( rgb0 );
	//	update();
	}
	public void setRGB(int rgb) {
		this.rgb = rgb;
		if( panes==null )return;
		for(int i=0 ; i<3 ; i++) {
			panes[i].setColor(rgb);
		}
		swatch.setColor( new Color(rgb ));
		swatch.repaint();
		firePropertyChange("COLOR_CHANGE", 0, rgb);
	}
	public int getRGB() {
		if( transS!=null ) {
			return (rgb&0x00ffffff) | (getTransparency()<<24);
		}
		return rgb;
	}
	public int showDialog(Component comp, int rgb) {
		setDefaultRGB( rgb );
		return showDialog( comp );
	}
	public int showDialog(Component comp) {
		int ok = JOptionPane.showConfirmDialog(
				comp,
				this,
				"color chooser",
				JOptionPane.OK_CANCEL_OPTION,
				JOptionPane.PLAIN_MESSAGE);
		if( ok==JOptionPane.CANCEL_OPTION) reset();
		return getRGB();
	}
	public static void main(String[] args) {
		ColorModPanel mod = new ColorModPanel(Color.pink.getRGB());
		int ok;
		while( (ok=mod.showDialog(null, mod.getRGB())) 
			!= JOptionPane.CANCEL_OPTION) ;
		System.exit(0);
	}
}
