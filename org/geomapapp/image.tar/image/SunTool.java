package org.geomapapp.image;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.MouseInputAdapter;

import org.geomapapp.geom.XYZ;
import org.geomapapp.util.SimpleBorder;

public class SunTool extends JComponent {
	XYZ sun;
	MouseInputAdapter mouse;
	JTextField inclination;
	JTextField declination;
	JPanel panel;
	java.text.NumberFormat fmt;
	public SunTool(XYZ toSun) {
		sun = toSun;
		sun.normalize();
		mouse = new MouseInputAdapter() {
			public void mouseClicked(MouseEvent evt) {
				mouseReleased(evt);
			}
			public void mouseReleased(MouseEvent evt) {
				apply( evt.getPoint() );
			}
			public void mouseDragged(MouseEvent evt) {
				drag( evt.getPoint() );
			}
		};
		addMouseListener(mouse);
		addMouseMotionListener(mouse);
		inclination = new JTextField(5);
		declination = new JTextField(5);
		fmt = java.text.NumberFormat.getInstance();
		fmt.setMaximumFractionDigits(1);
	}
	void initPanel() {
		ActionListener ac = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				setAngles();
				apply();
			}
		};
		inclination.addActionListener(ac);
		declination.addActionListener(ac);
		JPanel input = new JPanel(new GridLayout(0,1));
		input.add( new JLabel("Declination"));
		input.add(declination);
		input.add( new JLabel("Inclination"));
		input.add(inclination);
		SimpleBorder sb = new SimpleBorder();
		setBorder( sb );
		input.setBorder( sb );
		panel  = new JPanel(new GridLayout(1,0));
		panel.add(this);
		panel.add(input);
	}
	public JPanel getPanel() {
		if( panel==null )initPanel();
		return panel;
	}
	Point2D getXY() {
		if( !isVisible() ) return new Point();
		Rectangle r = getRect();
		double radius = .45*Math.min(r.width, r.height);
		double x0 = r.x+r.getWidth()/2.;
		double y0 = r.y+r.getHeight()/2.;
		if( sun.z>=1. ) return new Point2D.Double( x0, y0);
		double i = 1.-Math.asin(sun.z)*2./Math.PI;
		radius *= i;
		XYZ xyz = new XYZ(sun.x, sun.y, 0.);
		xyz.normalize();
		Point2D.Double p = new Point2D.Double( x0+radius*xyz.x,
						y0-radius*xyz.y);
		return p;
	}
	Rectangle getRect() {
		if( !isVisible() ) return null;
		Rectangle r = getVisibleRect();
		Insets ins = getInsets();
		r.x += ins.left;
		r.y += ins.top;
		r.width -= ins.left + ins.right;
		r.height -= ins.top + ins.bottom;
		return r;
	}
	void drag( Point p) {
		if( !isVisible() ) return;
		Rectangle r = getRect();
		double radius = .45*Math.min(r.width, r.height);
		double x0 = r.x + r.getWidth()/2.;
		double y0 = r.y + r.getHeight()/2.;
		sun.x = (p.getX()-x0)/radius;
		sun.y = (y0-p.getY())/radius;
		XYZ xyz = new XYZ( sun.x, sun.y, 0.);
		double i = xyz.getNorm();
		if( i>1. )i=1.;
		i = 90.*(1.-i);
		double d = Math.toDegrees(Math.atan2(sun.x, sun.y));
		inclination.setText( fmt.format(i));
		declination.setText( fmt.format(d));
		setAngles();
	}
	void apply(Point p) {
		drag(p);
		apply();
	}
	void apply() {
		firePropertyChange("SUN_CHANGED", new XYZ(), sun);
	}
	void setAngles() {
		try {
			sun.z = Math.sin(Math.toRadians(
				Double.parseDouble(inclination.getText())));
			if( sun.z<0. )sun.z = -sun.z;
			double f = Math.sqrt(1.-sun.z*sun.z);
			double d = Double.parseDouble(declination.getText());
			sun.x = f*Math.sin(Math.toRadians(d));
			sun.y = f*Math.cos(Math.toRadians(d));
		} catch(Exception ex) {
		}
		repaint();
	}
	public XYZ getSun() {
		return new XYZ(sun.x, sun.y, sun.z);
	}
	public Dimension getPreferredSize() {
		Insets ins = getInsets();
		Dimension size = new Dimension(100, 100);
		if( ins!=null ) {
			size.width += ins.left + ins.right;
			size.height += ins.top + ins.bottom;
		}
		return size;
	}
	public void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D)g;
		if( panel!=null ) {
			sun.normalize();
			double i = Math.toDegrees(Math.asin(sun.z));
			inclination.setText(fmt.format(i));
			double d = (sun.z==1.) ?
				0. :
				Math.toDegrees(Math.atan2(sun.x, sun.y));
			declination.setText(fmt.format(d));
		}
		AffineTransform at = g2.getTransform();
		Rectangle r = getRect();
		double radius = .45*Math.min(r.width, r.height);
		double x0 = r.x + r.getWidth()/2.;
		double y0 = r.y + r.getHeight()/2.;
		g2.setRenderingHint( RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		Arc2D.Double arc = new Arc2D.Double(x0-radius,
						y0-radius,
						2.*radius,
						2.*radius,
						0.,
						360.,
						Arc2D.CHORD);
		g2.setColor( new Color(80, 160, 240) );
		g2.fill(arc);
		g2.setColor(Color.black);
		g2.draw(arc);
		double rd = radius*2./3.;
		arc.x = x0-rd;
		arc.y = y0-rd;
		arc.width = arc.height = 2.*rd;
		g2.draw(arc);
		rd = radius/3.;
		arc.x = x0-rd;
		arc.y = y0-rd;
		arc.width = arc.height = 2.*rd;
		g2.draw(arc);
		Point2D p = getXY();
		arc.x = p.getX()-6.;
		arc.y = p.getY()-6.;
		arc.width = arc.height = 12.;
		g2.setColor(Color.yellow);
		g2.fill(arc);
		g2.setColor(Color.red);
		g2.draw(arc);
		g2.setTransform(at);
	}
}
