package org.geomapapp.image;

import java.awt.image.BufferedImage;
import javax.swing.*;
import java.io.*;
import java.util.*;
import java.awt.*;

public class Palette implements Cloneable {
	public final static int DEFAULT = 0;
	public final static int HAXBY = 0;
	public final static int OCEAN = 1;
	public final static int LAND  = 2;
	public final static int LAND_SEA  = 3;
	int ID;
	public final static String[] resources = new String[] {
				"default",
				"ocean",
				"land"};
			//	"land_sea"};
	float[] red, green, blue, ht;
	float[] range;
	float hScale;
	int[] rgbmap = new int[1001];
	int minRGB = 50;
	int maxRGB = 256;
	double gamma;
	String name;
	float interval;
	double ve;		// vertical exaggeration

	public Palette(float[] red, float[] green, float[] blue, float[] ht) {
		setGamma(1.);
		setModel( red, green, blue, ht);
		name = "unknown";
		ID = -1;
		interval = -1f;
		ve = 1.;
	}
	public Palette(int id) {
		setModel(id);
		setGamma(1.);
		ID = id;
	}
	public Palette(File file) throws IOException {
		readLUT( new FileInputStream(file) );
		name = file.getName();
		name = name.substring(0,name.indexOf(".lut"));
	}
	public int getID() {
		return ID;
	}
	public void setID(int id) {
		ID = id;
	}
	public String toString() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setModel(int id) {
		if(id<0 || id>=resources.length )id=0;
		try {
			ClassLoader cl = Palette.class.getClassLoader();
			String urlName = "org/geomapapp/resources/lut/"+resources[id]+".lut";
			java.net.URL url = cl.getResource(urlName);
			readLUT( url.openStream() );
			name = resources[id];
		} catch(IOException ex) {
			red = new float[] {0f, 1f};
			green = new float[] {0f, 1f};
			blue = new float[] {0f, 1f};
			ht = new float[] {0f, 1f};
			range = new float[] {ht[0], ht[ht.length-1]};
			hScale = 1f;
			ve = 1.;
			name = "unknown";
		}
	}
	JPanel savePanel;
	JTextField nameF;
	JCheckBox listCB, fileCB;
	void initSaveDialog() {
		savePanel = new JPanel(new GridLayout(0,1,2,2));
		JLabel label = new JLabel("Enter Palette Name");
		savePanel.add(label);
		nameF = new JTextField("MyPalette");
		savePanel.add(nameF);
		listCB = new JCheckBox("add to \"Palettes\" menu", true);
		fileCB = new JCheckBox("save to file", true);
		savePanel.add( listCB );
		savePanel.add( fileCB );
	}
	public Palette savePalette(Component comp) throws IOException {
		if( savePanel==null )initSaveDialog();
		File root = org.geomapapp.io.GMARoot.getRoot();
		boolean rootTF = root!=null;
		fileCB.setEnabled( rootTF );
		int ok = JOptionPane.showConfirmDialog(comp, savePanel,
			"Save Palette",
			JOptionPane.OK_CANCEL_OPTION);
		if( ok==JOptionPane.CANCEL_OPTION) return null;
		File dir = new File( root, "lut");
		if( !dir.exists() ) {
			if(!dir.mkdir()) throw new IOException(
					"unable to create directory");
		}
		File file = new File( dir, nameF.getText()+".lut");
		PrintStream out = new PrintStream(
			new FileOutputStream(file));
		Palette pal = (Palette)clone();
		out.println( ve +"");
		for(int k=0 ; k<ht.length ; k++) {
			float h = range[0]+(ht[k]-ht[0])/hScale;
			pal.ht[k] = h;
			int r = (int)Math.rint(255.*red[k]);
			int g = (int)Math.rint(255.*green[k]);
			int b = (int)Math.rint(255.*blue[k]);
			out.println(h +"\t"+ r +"\t"+ g +"\t"+ b);
		}
		pal.name = nameF.getText();
		pal.setVE( ve );
		out.close();
		JOptionPane.showMessageDialog( comp,
			"Palette \""+pal.name+" created in "+ dir.getPath());
		return  pal;
	}
				
	public void setModel(float[] red, float[] green, float[] blue, float[] ht) {
		this.red = (float[])red.clone();
		this.green = (float[])green.clone();
		this.blue = (float[])blue.clone();
		this.ht = (float[])ht.clone();
		range = new float[] {ht[0], ht[ht.length-1]};
		hScale = 1f;
	}
	public void setVE(double ve) {
		this.ve = ve;
	}
	public double getVE() {
		return ve;
	}
	void readLUT( InputStream input ) throws IOException {
		BufferedReader in = new BufferedReader(
				new InputStreamReader(input));
		ve = Double.parseDouble(in.readLine());
		String s;
		StringTokenizer st;
		Vector lut = new Vector();
		while( (s=in.readLine())!=null ) {
			st = new StringTokenizer(s);
			if( st.countTokens()<4 ) continue;
			lut.add( new float[] {
				Float.parseFloat(st.nextToken()),
				Float.parseFloat(st.nextToken()),
				Float.parseFloat(st.nextToken()),
				Float.parseFloat(st.nextToken())
				});
		}
		in.close();
		int size = lut.size();
		red = new float[size];
		green = new float[size];
		blue = new float[size];
		ht = new float[size];
		for( int k=0 ; k<size ; k++) {
			float[] tab = (float[])lut.get(k);
			ht[k] = tab[0];
			red[k] = tab[1]/255f;
			green[k] = tab[2]/255f;
			blue[k] = tab[3]/255f;
		}
		range = new float[] {ht[0], ht[ht.length-1]};
		hScale = 1f;
	}
	public void setDiscrete(double interval) {
		this.interval = (float)interval;
	}
	public float getScaledZ( int index ) {
		if( index<0 || index>=ht.length)return Float.NaN;
		return range[0] + (ht[index]-ht[0]) / hScale;
	}
	public void setScaledZ( int index, float z ) {
		if( index<0 || index>=ht.length)return;
		ht[index] = ht[0] + (z-range[0])*hScale;
	}
	float[] getColor(float h) {
		float z = ht[0] + (h-range[0]) * hScale;
		int nht = ht.length;
		if(z<=ht[0]) return new float[] {red[0], green[0], blue[0] };
		if(z>=ht[nht-1]) return new float[] {red[nht-1], green[nht-1], blue[nht-1] };
		int i=(nht-1)/2;
		int k1 = 0;
		int k2 = nht-1;
		while(true) {
			if(z>ht[i+1]) {
				k1=i;
				i=(i+k2)/2;
			} else if(z<ht[i]) {
				k2 = i;
				i=(i+k1)/2;
			} else break;
		}
		float dx = (z-ht[i]) / (ht[i+1]-ht[i]);
		float[] rgb = new float[] {red[i]+dx*(red[i+1]-red[i]),
					green[i] + dx * (green[i+1]-green[i]),
					blue[i] + dx * (blue[i+1]-blue[i]) };
		return rgb;
	}
	public float[][] getModel() {
		return new float[][] {
			(float[])ht.clone(),
			(float[])red.clone(),
			(float[])green.clone(),
			(float[])blue.clone()
		};
	}
	public float[] getControlPoints() {
		return (float[])ht.clone();
	}
	public int getRGB(float z) {
		if( interval>0f ) z = interval * (float)Math.floor(z/interval);
		float[] col = getColor(z);
		int rgb = (new java.awt.Color( col[0], col[1], col[2] )).getRGB();
		return rgb;
	}
	public int getRGB(float z, float shade ) {
		if(shade<.1f)shade=.1f;
		if( interval>0f ) z = interval * (float)Math.floor(z/interval);
		float[] rgb = getColor(z);
		float s1 = (shade>.5f)? (shade-.5f)*(shade-.5f)/(.5f) : 0f;
		for(int i=0 ; i<3 ; i++) rgb[i] = shade*rgb[i]+s1*(1f-rgb[i]);
		int c = 0xff000000 | rgbmap[(int)(rgb[0]*1000f)]<<16
				| rgbmap[(int)(rgb[1]*1000f)]<<8
				| rgbmap[(int)(rgb[2]*1000f)];
		return c;
	}
	public ImageIcon getIcon() {
		BufferedImage image = new BufferedImage( 32, 22,
				BufferedImage.TYPE_INT_RGB);
		float scale = hScale;
		float[] rng = getRange();
		setRange( 0f, 31f);
		for( int x=0 ; x<32 ; x++) {
			int rgb = getRGB((float)x);
			for(int y=0 ; y<22 ; y++) image.setRGB(x, y, rgb);
		}
		setRange( rng[0], rng[1]);
		return new ImageIcon( image);
	}
	public void setRGB(int index, float[] rgb) {
		if( index<0 || index>=ht.length)return;
		red[index] = rgb[0];
		green[index] = rgb[1];
		blue[index] = rgb[2];
	}
	public void resetRange() {
		range = new float[] {ht[0], ht[ht.length-1]};
		hScale = 1f;
	}
	public void setRange( float min, float max ) {
		range[0] = min;
		range[1] = max;
		hScale = (ht[ht.length-1] - ht[0]) / (range[1]-range[0] );
	}
	public float[] getRange() {
		return new float[] {range[0], range[1]};
	}
	public void setGamma(double g) {
		gamma = g;
		rgbmap[0] = 0;
		double scale = (double)(maxRGB-minRGB);
		for(int i=1 ; i<=1000 ; i++) {
			rgbmap[i] = minRGB + (int)Math.floor(scale*
				Math.pow( .001*(double)i, 1/gamma));
			if(rgbmap[i]>255) rgbmap[i]=255;
			if(rgbmap[i]<minRGB) rgbmap[i]=minRGB;
		}
	}
	public double getGamma() {
		return gamma;
	}
	public void saturate( float factor ) {
		if( factor<0f )return;
		if(factor>1f ) factor=1f;
		for( int i=0 ; i<red.length ; i++) {
			float max = red[i];
			if( green[i]>max) max=green[i];
			if( blue[i]>max) max=blue[i];
			float min = red[i];
			if( green[i]<min) min=green[i];
			if( blue[i]<min) min=blue[i];
			if( max==min) continue;
			float newMin =(1-factor)*min;
			red[i] = max - (max-red[i])*(max-newMin)/(max-min);
			green[i] = max - (max-green[i])*(max-newMin)/(max-min);
			blue[i] = max - (max-blue[i])*(max-newMin)/(max-min);
		}
	}
	public Object clone() {
		Palette pal = new Palette(red, green, blue, ht);
		pal.setVE(ve);
		return pal;
	}
}
