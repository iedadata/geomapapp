package org.geomapapp.util;

// import haxby.image.*;
import org.geomapapp.image.*;

import java.awt.*;
import java.beans.*;
import javax.swing.*;
import java.awt.image.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.imageio.*;
import java.io.*;

public class ImageComponent extends ScalableComponent {
	protected BufferedImage image = null;
	JFileChooser chooser = null;
	BalancePanel balance=null;
	JDialog colorDialog=null;
	protected File file=null;
	static BufferedImage logo;
	boolean showLogo=false;
	public ImageComponent() {
		setLayout(null);
		width = 800;
		height = 600;
	}
	public ImageComponent(JFileChooser chooser) {
		this();
		this.chooser = chooser;
	}
	public ImageComponent(File file) throws IOException {
		this();
		chooser = null;
		open(file);
	}
	public ImageComponent( BufferedImage image ) {
		this();
		this.image = image;
		width = image.getWidth();
		height = image.getHeight();
		file = null;
	}
	public void setChooser(JFileChooser chooser) {
		this.chooser = chooser;
	}
	public void addNotify() {
		super.addNotify();
		if( getTopLevelAncestor() instanceof JFrame ) {
			initBalance();
		}
	}
	void initBalance() {
		if(balance!=null) return;
		balance = new BalancePanel();
		balance.addPropertyChangeListener( new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if( evt.getPropertyName().equals("BRIGHTNESS") ) {
					repaint();
				} else if( evt.getPropertyName().equals("APPLY_MODS")) {
					apply();
				}
			}
		});
		colorDialog = new JDialog( (JFrame)getTopLevelAncestor(), "ColorBalance");
		colorDialog.getContentPane().add( balance );
		colorDialog.pack();
	}
	public void showColorDialog() {
		if(  colorDialog==null )return;
		colorDialog.show();
	}
	public boolean open() throws IOException {
		initChooser();
		Container c = getTopLevelAncestor();
		int ok = chooser.showOpenDialog(c);
		if( ok==chooser.CANCEL_OPTION ) return false;
		open( chooser.getSelectedFile() );
		return true;
	}
	void initChooser() {
		if( chooser==null ) chooser = new JFileChooser(
				System.getProperty("user.dir"));
	}
	public void open(File file) throws IOException {
		BufferedImage image = ImageIO.read( file );
		if(image==null)return;
		this.image = image;
		width = image.getWidth();
		height = image.getHeight();
		this.file = file;
		repaint();
	}
	public File getFile() {
		return file;
	}
	public BufferedImage getImage() {
		return image;
	}
	public void save() throws IOException {
		initChooser();
		int ok = JOptionPane.NO_OPTION;
		if( file!=null ) {
			ok = JOptionPane.showConfirmDialog(
				(JFrame)getTopLevelAncestor(),
				"overwrite "+file.getName()+"?",
				"overwrite?",
				JOptionPane.YES_NO_CANCEL_OPTION);
			if( ok==JOptionPane.CANCEL_OPTION) return;
			chooser.setSelectedFile( file);
		}
		if( ok==JOptionPane.NO_OPTION) {
			ok = chooser.showSaveDialog((JFrame)getTopLevelAncestor());
			if( ok==chooser.CANCEL_OPTION) return;
			file = chooser.getSelectedFile();
		}
		apply();
		String type = file.getName().substring(
			file.getName().indexOf(".")+1).toLowerCase();
		if( !type.equals("jpg") && !type.equals("png")) type="jpg";
		ImageIO.write( image, type, file);
	}
	public void paintComponent(Graphics g) {
		if(image==null) return;
		Insets ins = getInsets();
		Graphics2D g2 = (Graphics2D) g;
		AffineTransform at0 = g2.getTransform();
		if( ins!=null) {
			g2.translate(ins.left, ins.top);
		}
		ByteLookupTable lookup = balance==null ? null
				: balance.getLookup();
		if(lookup!=null) {
			g2.transform(getTransform());
			g2.drawImage( image, new LookupOp( lookup, null ), 0, 0);
			g2.setTransform( at0 );
		} else {
			g2.drawRenderedImage(image, getTransform());
			g2.setTransform( at0 );
		}
/*
		if( showLogo || logo!=null ) {
			Rectangle r = getVisibleRect();
			int x = r.x+r.width-logo.getWidth();
			int y = r.y+r.height-logo.getHeight();
			if( ins!=null) {
				x -= ins.bottom;
				y -= ins.right;
			}
			AffineTransform at = new AffineTransform();
			at.translate(x,y);
			g2.drawRenderedImage( logo, at);
		}
*/
	}
	public void rotate( Point2D center, double angle ) {
		BufferedImage im = new BufferedImage( width, height, image.TYPE_INT_RGB);
		Graphics2D g = im.createGraphics();
		AffineTransform at = new AffineTransform();
		at.rotate( -angle, center.getX(), center.getY() );
		g.drawRenderedImage( image, at);
		image = im;
		repaint();
	}
	public void apply() {
		if( balance==null ) return;
		ByteLookupTable lookup = balance.getLookup();
		if(lookup==null) return;
		int ok = JOptionPane.showConfirmDialog(
			(JFrame)getTopLevelAncestor(),
			"Apply Color Mods?",
			"Modify Image Color",
			JOptionPane.YES_NO_OPTION);
		if( ok== JOptionPane.NO_OPTION) return;
		BufferedImage im = new BufferedImage( width, height, 
			image.TYPE_INT_RGB);
		Graphics2D g = im.createGraphics();
		g.drawImage( image, new LookupOp( lookup, null ), 0, 0);
		image = im;
		balance.reset();
	}
	public void setImage(BufferedImage image) {
		if( this.image == image) return;
		this.image = image;
		width = image.getWidth();
		height = image.getHeight();
		if( logo!=null && showLogo ) {
			Graphics2D g = image.createGraphics();
			g.drawImage( logo, 
				image.getWidth()-logo.getWidth(),
				image.getHeight()-logo.getHeight(),
				this);
		}
		if( isVisible() ) repaint();
	}
	public void addLogo() {
		if( logo==null ) {
			if(!getLogo()) return;
		}
		Graphics2D g = image.createGraphics();
		g.drawImage( logo, 
			image.getWidth()-logo.getWidth(),
			image.getHeight()-logo.getHeight(),
			this);
		showLogo=true;
	}
	boolean getLogo() {
		try {
			ClassLoader loader  = org.geomapapp.util.Icons.class.getClassLoader();
			String path = "org/geomapapp/resources/icons/gma.png";
			java.net.URL url = loader.getResource(path);
			logo = ImageIO.read(url);
			return true;
		} catch(Exception ex) {
			return false;
		}
	}
}
