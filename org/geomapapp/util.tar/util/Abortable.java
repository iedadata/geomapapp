package org.geomapapp.util;

public abstract interface Abortable {
	public void abort();
}
