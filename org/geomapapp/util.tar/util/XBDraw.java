package org.geomapapp.util;

import java.awt.*;
import java.io.*;
import java.util.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.*;
import javax.swing.event.MouseInputAdapter;
import java.beans.*;

public class XBDraw {
	ImageComponent image;
	JPanel tools;
	TextOverlay txt;

	public XBDraw( ImageComponent image ) {
		this.image = image;
		JFrame frame = new JFrame("XBDraw");
		initTools();
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.getContentPane().add(new JScrollPane(image));
		frame.getContentPane().add(tools, "North");
		Zoomer z = new Zoomer(image);
		image.addMouseListener(z);
		image.addMouseMotionListener(z);
		image.addKeyListener(z);
		frame.pack();
		frame.show();
	}
	void initTools() {
		tools = new JPanel(new GridLayout(1, 0));
		JButton b = new JButton("T");
		tools.add(b);
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				text();
			}
		});
		b = new JButton("I");
		tools.add(b);
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				image();
			}
		});
		b = new JButton("R");
		tools.add(b);
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				box();
			}
		});
		b = new JButton("Save");
		tools.add(b);
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				save();
			}
		});
		b = new JButton("open");
		tools.add(b);
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				open();
			}
		});
	}
	void open() {
		try {
			image.open();
			image.removeAll();
		} catch(Exception ex) {
			ex.printStackTrace(System.err);
			System.exit(-1);
		}
	}
	void save() {
		JFileChooser chooser = image.chooser;
		int ok = chooser.showSaveDialog(null);
		if( ok==chooser.CANCEL_OPTION )return;
		File file = chooser.getSelectedFile();
		String name = file.getName();
		String type = file.getName().substring(
				file.getName().indexOf(".")+1).toLowerCase();
		if( !type.equals("jpg") && !type.equals("png")) type="jpg";
		image.resetTransform();
		Dimension dim = image.getPreferredSize();
		BufferedImage im = new BufferedImage(dim.width, dim.height, 
				BufferedImage.TYPE_INT_RGB);
		Graphics2D g = im.createGraphics();
		image.paint(g);
		try {
			ImageIO.write( im, type, file);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	void box() {
		RectangleOverlay ovl = new RectangleOverlay();
		image.add(ovl,0);
	}
	void text() {
		Font font =(txt==null) ? null : txt.hideDialog();
		txt = new TextOverlay(font);
		image.add(txt,0);
		txt.showDialog();
	}
	void image() {
		JFileChooser chooser = image.chooser;
		int ok = chooser.showOpenDialog(null);
		if( ok==chooser.CANCEL_OPTION )return;
		try {
			java.awt.image.BufferedImage im = ImageIO.read(chooser.getSelectedFile());
			ImageOverlay ovl = new ImageOverlay(im);
			image.add(ovl,0);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	public static void main(String[] args) {
		ImageComponent im = new ImageComponent();
		try {
			im.open();
		} catch(Exception ex) {
			ex.printStackTrace(System.err);
			System.exit(-1);
		}
		new XBDraw(im);
	}
}
