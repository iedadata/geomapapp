package org.geomapapp.grid;

import haxby.proj.*;

import ucar.nc2.*;
import ucar.ma2.*;
import java.util.*;
import java.io.*;

public class Grd {
	Grid2D.Float grid;
	String source;
	Grd() {
	}
	public static Grid2D.Float readGrd(String fileName) throws IOException {
		Grd grd = new Grd();
		NetcdfFile nc = null;
		try {
			nc = new NetcdfFile(fileName);
		} catch(java.lang.IllegalArgumentException ex) {
			IOException e = new IOException("Not a netcdf file");
			e.fillInStackTrace();
			throw e;
		}
		Iterator vi = nc.getGlobalAttributeIterator();
		while(vi.hasNext()) {
			Attribute v = (Attribute) vi.next();
			if( v.getName().equals("source") ) grd.source = v.getStringValue();
		}
		vi = nc.getVariableIterator();
		double[] x_range = null;
		double[] y_range = null;
		double[] z_range = null;
		double[] spacing = null;
		int[] dimension = null;
		float[] z = null;
		double scaleFactor=1.;
		double add_offset=0.;
		int node_offset=0;
		while(vi.hasNext()) {
			Variable v = (Variable) vi.next();
			if( v.getName().equals( "x_range" )) {
				x_range = (double[])v.read().copyTo1DJavaArray();
			} else if( v.getName().equals( "y_range" )) {
				y_range = (double[])v.read().copyTo1DJavaArray();
			} else if( v.getName().equals( "z_range" )) {
				z_range = (double[])v.read().copyTo1DJavaArray();
			} else if( v.getName().equals( "spacing" )) {
				spacing = (double[])v.read().copyTo1DJavaArray();
			} else if( v.getName().equals( "dimension" )) {
				dimension = (int[])v.read().copyTo1DJavaArray();
			} else if( v.getName().equals( "z" )) {
				Iterator it = v.getAttributeIterator();
				while(it.hasNext()) {
					Attribute att = (Attribute) it.next();
					if( att.getName().equals("scale_factor") ) {
						scaleFactor = att.getNumericValue().doubleValue();
					} else if( att.getName().equals("add_offset") ) {
						add_offset = att.getNumericValue().doubleValue();
					} else if( att.getName().equals("node_offset") ) {
						node_offset = att.getNumericValue().intValue();
					}
				}
				z = (float[])v.read().copyTo1DJavaArray();
			}
		}
		if( node_offset==1 ) {
			x_range[0] += .5*spacing[0];
			x_range[1] -= .5*spacing[0];
			y_range[0] += .5*spacing[1];
			y_range[1] -= .5*spacing[1];
		}
		RectangularProjection proj = new RectangularProjection(
			new double[] { x_range[0], x_range[1], y_range[0], y_range[1] },
			dimension[0], dimension[1]);
		Grid2D.Float grid = new Grid2D.Float( new java.awt.Rectangle(0, 0, dimension[0], dimension[1]),
					proj);
		return grid;
	}
	public static void main(String[] args) {
		if(args.length != 1) {
			System.out.println("usage: java Grd filename");
			System.exit(0);
		}
		try {
			Grid2D.Float grd = Grd.readGrd( args[0] );
		} catch(IOException ex) {
			ex.printStackTrace();
		}
	}
}
