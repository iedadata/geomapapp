package org.geomapapp.grid;

import ucar.nc2.*;
import ucar.ma2.*;
import java.util.*;
import java.io.*;

public class TestCDF {
	public static void main(String[] args) {
		if(args.length != 1) {
			System.out.println("usage: java testCDF filename");
			System.exit(0);
		}
		new TestCDF(args[0]);
	}
	public TestCDF(String fileName) {
		try {
			NetcdfFile nc = new NetcdfFile(fileName);
		//	System.out.println(nc);
			Iterator vi = nc.getGlobalAttributeIterator();
			while(vi.hasNext()) {
				Attribute v = (Attribute) vi.next();
				System.out.println("attribute: "+v.getName()+" "+v.getStringValue());
			}
			vi = nc.getVariableIterator();
			while(vi.hasNext()) {
				Variable v = (Variable) vi.next();
				int rank = v.getRank();
				System.out.println("variable: "+v.getName() 
						+": rank = "+rank);
				System.out.println("  class:\t"+ v.getElementType().toString());
				int[] shape = v.getShape();
				for(int i=0 ; i<shape.length ; i++) {
					System.out.println("\t"+ i +":\t"
						+ v.getDimension(i).getLength() 
						+" elements\t");
				}
				if(v.getRank() == 1) {
					Iterator it = v.getAttributeIterator();
					while(it.hasNext()) {
						Attribute att = (Attribute) it.next();
						System.out.println("\tattribute: "
							+att.getName()+" "+att.getValueType().toString());
					}
					Array a = v.read();
					if(v.getElementType().equals(float.class)) {
						float[] fArray = (float[]) a.copyTo1DJavaArray();
						System.out.println("\t\t"+fArray[0] +"\t"+ fArray[1]);
					} else if(v.getElementType().equals(double.class)) {
						double[] dArray = (double[]) a.copyTo1DJavaArray();
						System.out.println("\t\t"+dArray[0] +"\t"+ dArray[1]);
					} else if(v.getElementType().equals(int.class)) {
						int[] dArray = (int[]) a.copyTo1DJavaArray();
						System.out.println("\t\t"+dArray[0] +"\t"+ dArray[1]);
					}
				}
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
