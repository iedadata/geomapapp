package org.geomapapp.grid;

import org.geomapapp.geom.*;

import java.io.*;
import java.net.URL;
import java.awt.Rectangle;
import java.util.zip.*;
import java.util.StringTokenizer;
import javax.swing.JLabel;

public abstract class TileIO {
	public final static String BASE_DIR_MERC = 
		"/scratch/ridgembs/bill/grid/final/merc_320_1024";
	public final static String BASE_URL_MERC = 
		"http://ocean-ridge.ldeo.columbia.edu/MapApp/merc_320_1024";
	public final static String BASE_DIR_SP = 
		"/scratch/ridgembs/bill/antarctic/public/SP_320_50";
	public final static String BASE_URL_SP = 
		"http://ocean-ridge.ldeo.columbia.edu/antarctic/SP_320_50";
	protected MapProjection proj;
	protected int gridSize;
	protected String root;
	protected boolean remote;
	protected boolean readonly;
	protected String separator;
	protected int nLevel;
	protected JLabel label;
	DataInputStream in;
	protected TileIO(MapProjection proj, 
			String root,
			int gridSize,
			int nLevel) {
		this.proj = proj;
		this.gridSize = gridSize;
		readonly = true;
		remote = root.toLowerCase().startsWith("http://");
		separator = remote ? "/" :
			System.getProperty("file.separator");
		if( !root.endsWith(separator) ) root += separator;
		this.root = root;
		this.nLevel = nLevel;
	}
	protected TileIO(MapProjection proj, 
			String root,
			int gridSize) {
		this( proj, root, gridSize, 0);
		getNLevel();
	}
	public void abort() {
		try {
			in.close();
		} catch(Exception ex) {
		}
	}
	public void setReadonly(boolean tf) {
		if(remote)return;
		readonly = tf;
	}
	public boolean isReadonly() {
		return readonly;
	}
	public void setLabel(JLabel label) {
		this.label = label;
	}
	public static int[] getIndices(String tileName) {
		StringTokenizer st = new StringTokenizer(tileName, "EWNS_", true);
		try {
			boolean west = st.nextToken().equals("W");
			int E = Integer.parseInt( st.nextToken() );
			if( west ) E = -E;
			boolean south = st.nextToken().equals("S");
			int N = Integer.parseInt( st.nextToken() );
			if( south ) N = -N;
			return new int[] {E, N};
		} catch(Exception ex) {
			return null;
		}
	}
	public static String getName(int x, int y, int gridSize) {
		int xx = (int)Math.floor( (double)x/(double)gridSize );
		int yy = (int)Math.floor( (double)y/(double)gridSize );
		return ( (xx>=0) ? "E"+xx : "W"+(-xx) )
			+ ( (yy>=0) ? "N"+yy : "S"+(-yy) )
			+ "_" + gridSize;
	}
	public String getName(int x, int y) {
		return getName( x, y, gridSize);
	}
	public String getDirPath( int x, int y) {
		int xx = (int)Math.floor( (double)x/(double)gridSize );
		int yy = (int)Math.floor( (double)y/(double)gridSize );
		int factor = 8;
		for( int k=1 ; k<nLevel ; k++) factor *=8;
		String path = root;
		for( int k=0 ; k<nLevel ; k++) {
			int xG = factor*(int)Math.floor( (double)xx / (double)factor);
			int yG = factor*(int)Math.floor( (double)yy / (double)factor);
			path += getName(gridSize*xG, gridSize*yG)+separator;
			factor /= 8;
		}
		return path;
	}
	public void setNLevel(int n) {
		nLevel = n;
	}
	void getNLevel() {
		try {
			BufferedReader in = new BufferedReader(
				remote ?
				  new InputStreamReader(
					(new URL(root+"n_level")).openStream())
				: new FileReader(root+"n_level") );
			nLevel = Integer.parseInt( in.readLine() );
			in.close();
		} catch (IOException ex) {
			nLevel=0;
		}
	}
	public abstract Grid2D readGridTile(int x, int y)
					throws IOException;

	public abstract Grid2D createGridTile(int x, int y);

	public abstract void writeGridTile(Grid2D tile)
					throws IOException;

	public static class Float extends TileIO {
		public Float(MapProjection proj, 
				String root, 
				int gridSize) {
			super( proj, root, gridSize);
		}
		public Float(MapProjection proj, 
				String root, 
				int gridSize,
				int nLevel) {
			super( proj, root, gridSize, nLevel);
		}
		public Grid2D readGridTile(int x, int y) 
					throws IOException {
			String path = getDirPath( x, y);
			path += getName(x, y)+".zgrid";
			if( label!=null) label.setText( "reading "+path);
// System.out.println(path);
			in =null;
			if(remote) {
				URL url = new URL(path);
				in = new DataInputStream(
					url.openStream());
			} else {
				File file = new File(path);
				if( !file.exists() )return null;
				in = new DataInputStream(
					new BufferedInputStream(
					new FileInputStream(file)));
			}
			Grid2D.Float tile = (Grid2D.Float)createGridTile(x,y);
			Rectangle bounds = tile.getBounds();
			int i=0;
			int n;
			int size = gridSize*gridSize;
			while( i<size ) {
				n = in.readInt();
				i += n;
				if( i<size ) {
					n = in.readInt();
					x = i%gridSize;
					y = i/gridSize;
					for( int k=0 ; k<n ; k++) {
						tile.setValue(bounds.x+x, 
							bounds.y+y, 
							in.readFloat());
						x++;
						if(x==gridSize) {
							x=0;
							y++;
						}
					}
					i += n;
				}
			}
			return tile;
		}
		public Grid2D createGridTile(int x, int y) {
			x = (int)Math.floor( (double)x/(double)gridSize );
			y = (int)Math.floor( (double)y/(double)gridSize );
			return new Grid2D.Float(
					new Rectangle(x*gridSize,
						y*gridSize,
						gridSize,
						gridSize),
					proj);
		}
		public void writeGridTile(Grid2D tile) 
		 			throws IOException {
			if( remote )throw new IOException("cannot write to URL");
			if( !(tile instanceof Grid2D.Float) ) {
				throw new IOException("wrong grid type");
			}
			float[] grid = ((Grid2D.Float)tile).getBuffer();
			if( grid==null )return;
			Rectangle bounds = tile.getBounds();
			if( gridSize != bounds.width ) {
				throw new IOException("inconsistent grid size");
			}
			int x = bounds.x;
			int y = bounds.y;
			String path = getDirPath(x, y);
			File file = new File(path);
			if( !file.exists() ) file.mkdirs();
			file = new File(file, getName(x, y)+".zgrid");
			DataOutputStream out = new DataOutputStream(
					new BufferedOutputStream(
					new FileOutputStream(file)));
			int i=0;
			int n;
			while(i<grid.length) {
				n=0;
				while( i<grid.length && java.lang.Float.isNaN(grid[i]) ) {
					n++;
					i++;
				}
				out.writeInt(n);
				if( i>=grid.length ) break;
				n=0;
				while( i+n<grid.length && !java.lang.Float.isNaN(grid[i+n]) ) n++;
				out.writeInt(n);
				for( int k=0 ; k<n ; k++) {
					out.writeFloat(grid[i]);
				}
			}
			out.close();
		}
	}
	public static class Short extends TileIO {
		public final static short NaN = -32768;
		public Short(MapProjection proj, 
					String root, 
					int gridSize) {
			super( proj, root, gridSize);
		}
		public Short(MapProjection proj, 
					String root, 
					int gridSize,
					int nLevel) {
			super( proj, root, gridSize, nLevel);
		}
		public Grid2D readGridTile(int x, int y) 
					throws IOException {
			String path = getDirPath( x, y);
			path += getName(x, y)+".igrid.gz";
			if( label!=null) label.setText( "reading "+path);
//	System.out.println(path);
			in =null;
			if(remote) {
				URL url = new URL(path);
				in = new DataInputStream(
					new GZIPInputStream(
					url.openStream()));
			} else {
				File file = new File(path);
				if( !file.exists() )throw new IOException("non-existent file");
				in = new DataInputStream(
					new BufferedInputStream(
					new GZIPInputStream(
					new FileInputStream(file))));
			}
			Grid2D.Short tile = (Grid2D.Short)createGridTile(x, y);
			int i=0;
			int size = gridSize*gridSize;
			int n = in.readInt();
			double offset = 0.;
			double scale = 1.;
			if( n<0 ) {
				offset = in.readDouble();
				scale = in.readDouble();
				tile.scale(offset, scale);
				n = in.readInt();
			}
			byte[] buf = new byte[n];
			in.readFully( buf );
			in.close();

			short[] grid = XgrdIO.decode( buf, size );
			if( grid.length!=size ) {
				throw new IOException( "incorrect length: "+
						grid.length +" ("+ (size*size) +")");
			}
			tile.setBuffer( grid );
			for(y=0 ; y<gridSize ; y++) {
				for(x=0 ; x<gridSize ; x++) {
					tile.setValue(x, y, grid[i++]);
				}
			}
			return tile;
		}
		public Grid2D createGridTile(int x, int y) {
//	System.out.println("+ "+getDirPath(x, y));
			x = (int)Math.floor( (double)x/(double)gridSize );
			y = (int)Math.floor( (double)y/(double)gridSize );
			return new Grid2D.Short(
					new Rectangle(x*gridSize,
						y*gridSize,
						gridSize,
						gridSize),
					proj);
		}
		public void writeGridTile(Grid2D tile) 
		 			throws IOException {
			if( remote )throw new IOException("cannot write to URL");
			if( !(tile instanceof Grid2D.Short) ) {
				throw new IOException("wrong grid type");
			}
			Rectangle bounds = tile.getBounds();
			if( gridSize != bounds.width ) {
				throw new IOException("inconsistent grid size");
			}
			Grid2D.Short sTile = (Grid2D.Short)tile;
			short[] grid = sTile.getBuffer();
			if( grid==null )return;
			int x = bounds.x;
			int y = bounds.y;
			String path = getDirPath(x, y);
			File file = new File(path);
			if( !file.exists() ) file.mkdirs();
			file = new File(file, getName(x, y)+".igrid.gz");
			DataOutputStream out = new DataOutputStream(
					new BufferedOutputStream(
					new GZIPOutputStream(
					new FileOutputStream(file))));
			if( sTile.isScaled() ) {
				double[] scales = sTile.getScales();
				out.writeInt( -1 );
				out.writeDouble( scales[0] );
				out.writeDouble( scales[1] );
			}
			int i=0;
			int n;
			byte[] buf = XgrdIO.encode( grid );
			n = buf.length;
			out.writeInt( n );
			out.write( buf, 0, n);
			out.close();
		}
	}
	public static class Boolean extends TileIO {
		public Boolean(MapProjection proj, 
					String root, 
					int gridSize) {
			super( proj, root, gridSize);
		}
		public Boolean(MapProjection proj, 
					String root, 
					int gridSize,
					int nLevel) {
			super( proj, root, gridSize, nLevel);
		}
		public Grid2D readGridTile(int x, int y) 
					throws IOException {
			String path = getDirPath( x, y);
			path += getName(x, y)+".bgrid.gz";
			if( label!=null) label.setText( "reading "+path);
//	System.out.println(path);
			in =null;
			if(remote) {
				URL url = new URL(path);
				in = new DataInputStream(
					new GZIPInputStream(
					url.openStream()));
			} else {
				File file = new File(path);
				if( !file.exists() )throw new IOException("non-existent file");
				in = new DataInputStream(
					new BufferedInputStream(
					new GZIPInputStream(
					new FileInputStream(file))));
			}
			Grid2D.Boolean tile = (Grid2D.Boolean)createGridTile(x, y);
			int i=0;
			int size = gridSize*gridSize;
			size = (size+7)>>3;
			byte[] buf = new byte[size];
			in.readFully( buf );
			in.close();

			tile.setBuffer(buf);
			return tile;
		}
		public Grid2D createGridTile(int x, int y) {
//	System.out.println("+ "+getDirPath(x, y));
			x = (int)Math.floor( (double)x/(double)gridSize );
			y = (int)Math.floor( (double)y/(double)gridSize );
			return new Grid2D.Boolean(
					new Rectangle(x*gridSize,
						y*gridSize,
						gridSize,
						gridSize),
					proj);
		}
		public void writeGridTile(Grid2D tile) 
		 			throws IOException {
			if( remote )throw new IOException("cannot write to URL");
			if( !(tile instanceof Grid2D.Boolean) ) {
				throw new IOException("wrong grid type");
			}
			Rectangle bounds = tile.getBounds();
			if( gridSize != bounds.width ) {
				throw new IOException("inconsistent grid size");
			}
			byte[] grid = ((Grid2D.Boolean)tile).getBuffer();
			if( grid==null )return;
			int x = bounds.x;
			int y = bounds.y;
			String path = getDirPath(x, y);
			File file = new File(path);
			if( !file.exists() ) file.mkdirs();
			file = new File(file, getName(x, y)+".bgrid.gz");
			DataOutputStream out = new DataOutputStream(
					new BufferedOutputStream(
					new GZIPOutputStream(
					new FileOutputStream(file))));
			int i=0;
			int n;
			out.write( grid, 0, grid.length);
			out.close();
		}
	}
}
