package org.geomapapp.grid;

import org.geomapapp.geom.MapProjection;
import haxby.proj.*;
import haxby.map.*;

import com.sun.image.codec.jpeg.*;
import java.net.*;
import java.io.*;
import java.awt.Rectangle;
import java.awt.geom.*;
import java.awt.image.BufferedImage;

public class GridComposer {
//	static String base = "/local/data/home/bill/db/merc_320_1024/";
	static String base = "http://ocean-ridge.ldeo.columbia.edu/MapApp/merc_320_1024/";
	public static void setBaseURL( String baseURL ) {
		base = baseURL;
		if(!base.endsWith("/")) base += "/";
	}
	public static boolean getGrid(Rectangle2D rect, 
				Grid2DOverlay overlay, 
				int mapRes) {
		double zoom = overlay.getXMap().getZoom();
		int res = mapRes;
		while(zoom*res/mapRes > 1.5 && res>1) {
			res /=2;
		}
		int scale = mapRes/res;
		int x = (int)Math.floor(scale*rect.getX());
		int y = (int)Math.floor(scale*(rect.getY()-260.));
		int width = (int)Math.ceil( 
			scale*(rect.getX()+rect.getWidth()) ) - x;
		int height = (int)Math.ceil( 
			scale*(rect.getY()-260.+rect.getHeight()) ) - y;
		Rectangle r0 = new Rectangle( 0, -260*scale, 640*scale,
					260*2*scale);
		Projection proj = ProjectionFactory.getMercator( 1024*320/res );
		Rectangle bounds = new Rectangle(x, y, width, height);
		int nLevel = 0;
		int nGrid = 1024/res;
		while( nGrid>8 ) {
			nLevel++;
			nGrid /= 8;
		}
		Grid2D.Short grid = new Grid2D.Short( bounds, proj);
		TileIO tileIO = new TileIO.Short( proj,
				base + "srtm/z_" + res,
				320, nLevel);
		TiledGrid tiler = new TiledGrid( proj, 
						r0,
						tileIO,
						320,
						1,
						null);
		tiler.setWrap( 1024*320/res );
		grid = (Grid2D.Short)tiler.composeGrid(grid);

		Grid2D.Boolean land = new Grid2D.Boolean(bounds, proj);
		boolean hasOcean = true;
		boolean hasLand = false;
		if( grid.getBuffer()!=null ) {
			hasLand = true;
			hasOcean = false;
			Grid2D.Short ogrid = new Grid2D.Short( bounds, proj);
			tileIO = new TileIO.Short( proj,
				base + "ocean/z_" + res,
				320, nLevel);
			tiler = new TiledGrid( proj, 
						r0,
						tileIO,
						320,
						1,
						null);
			tiler.setWrap( 1024*320/res );
			ogrid = (Grid2D.Short)tiler.composeGrid(ogrid);
			for( x=bounds.x ; x<bounds.x+bounds.width ; x++) {
				for( y=bounds.y ; y<bounds.y+bounds.height ; y++) {
					boolean tf = ogrid.shortValue(x,y)==0;
					land.setValue(x, y, tf);
					if( !tf )hasOcean = true;
				}
			}
		}
		if( hasOcean ) {
			tileIO = new TileIO.Short( proj,
				base + "multibeam/z_" + res,
				320, nLevel);
			tiler = new TiledGrid( proj, 
					r0,
					tileIO,
					320,
					1,
					null);
			tiler.setWrap( 1024*320/res );
			grid = (Grid2D.Short)tiler.composeGrid(grid);
			if( res<4 ) {
				double factor = .25*res;
				scale = mapRes/4;
				int x4 = (int)Math.floor(scale*rect.getX())-2;
				int y4 = (int)Math.floor(scale*(rect.getY()-260.))-2;
				int width4 = 4 + (int)Math.ceil(
					scale*(rect.getX()+rect.getWidth()) ) - x4;
				int height4 = 4 + (int)Math.ceil( 
					scale*(rect.getY()-260.+rect.getHeight()) ) - y4;
				r0 = new Rectangle( 0, -260*scale, 640*scale,
					260*2*scale);
				Projection proj4 = ProjectionFactory.getMercator( 
							1024*320/4 );
				Rectangle bounds4 = new Rectangle(x4, y4, width4, height4);
				nLevel = 0;
				nGrid = 1024/4;
				while( nGrid>8 ) {
					nLevel++;
					nGrid /= 8;
				}
				Grid2D.Short g4 = new Grid2D.Short( bounds4, proj4);
				TileIO t4 = new TileIO.Short( proj4,
						base + "multibeam/z_4",
						320, nLevel);
				tiler = new TiledGrid( proj4, 
					r0,
					t4,
					320,
					1,
					null);
				tiler.setWrap( 1024*320/4 );
				g4 = (Grid2D.Short)tiler.composeGrid(g4);
				for( x=bounds.x ; x<bounds.x+bounds.width ; x++) {
					for( y=bounds.y ; y<bounds.y+bounds.height ; y++) {
						if( grid.shortValue(x,y) != grid.NaN )continue;
						if( hasLand && land.booleanValue(x,y) ) continue;
						grid.setValue(x, y, 
							g4.valueAt(factor*x, factor*y));
					}
				}
			}
			if( res<32 ) {
				double factor = res/32.;
				scale = mapRes/32;
				int x4 = (int)Math.floor(scale*rect.getX())-2;
				int y4 = (int)Math.floor(scale*(rect.getY()-260.))-2;
				int width4 = 4 + (int)Math.ceil(
					scale*(rect.getX()+rect.getWidth()) ) - x4;
				int height4 = 4 + (int)Math.ceil( 
					scale*(rect.getY()-260.+rect.getHeight()) ) - y4;
				r0 = new Rectangle( 0, -260*scale, 640*scale,
					260*2*scale);
				Projection proj4 = ProjectionFactory.getMercator( 
							1024*320/32 );
				Rectangle bounds4 = new Rectangle(x4, y4, width4, height4);
				nLevel = 0;
				nGrid = 1024/32;
				while( nGrid>8 ) {
					nLevel++;
					nGrid /= 8;
				}
				Grid2D.Short g4 = new Grid2D.Short( bounds4, proj4);
				TileIO t4 = new TileIO.Short( proj4,
						base + "multibeam/z_32",
						320, nLevel);
				tiler = new TiledGrid( proj4, 
					r0,
					t4,
					320,
					1,
					null);
				tiler.setWrap( 1024*320/32 );
				g4 = (Grid2D.Short)tiler.composeGrid(g4);
				for( x=bounds.x ; x<bounds.x+bounds.width ; x++) {
					for( y=bounds.y ; y<bounds.y+bounds.height ; y++) {
						if( grid.shortValue(x,y) != grid.NaN ) {
							continue;
						}
						if( hasLand && land.booleanValue(x,y) ) continue;
						grid.setValue(x, y,
							g4.valueAt(factor*x, factor*y));
					}
				}
			}
		}
		if( !hasLand ) {
			for( x=bounds.x ; x<bounds.x+bounds.width ; x++) {
				for( y=bounds.y ; y<bounds.y+bounds.height ; y++) {
					boolean tf = grid.shortValue(x,y)>=0;
					land.setValue( x, y, grid.shortValue(x,y)>=0 );
					if( tf ) hasLand=true;
				}
			}
			
		}
		overlay.setGrid(grid, land, hasLand, hasOcean);
		return true;
	}
	public static boolean getMask(Rectangle2D rect, 
				MapOverlay overlay, 
				int mapRes) {
		double zoom = overlay.getXMap().getZoom();
		int res = mapRes;
		while(zoom*res/mapRes > 1.5 && res>1) {
			res /=2;
		}
		if( res!=mapRes ) res*=2;
		int scale = mapRes/res;
		int x = (int)Math.floor(scale*rect.getX());
		int y = (int)Math.floor(scale*(rect.getY()-260.));
		int width = (int)Math.ceil( 
			scale*(rect.getX()+rect.getWidth()) ) - x;
		int height = (int)Math.ceil( 
			scale*(rect.getY()-260.+rect.getHeight()) ) - y;
		Rectangle r0 = new Rectangle( 0, -260*scale, 640*scale,
					260*2*scale);
		Projection proj = ProjectionFactory.getMercator( 1024*320/res );
		Rectangle bounds = new Rectangle(x, y, width, height);
		int nLevel = 0;
		int nGrid = 1024/res;
		while( nGrid>8 ) {
			nLevel++;
			nGrid /= 8;
		}
		Grid2D.Boolean grid = new Grid2D.Boolean( bounds, proj);
		TileIO.Boolean tileIO = new TileIO.Boolean( proj,
				base + "mask/m_" + res,
				320, nLevel);
		TiledMask tiler = new TiledMask( proj, 
						r0,
						tileIO,
						320,
						1,
						(TiledMask)null);
		tiler.setWrap( 1024*320/res );
		grid = (Grid2D.Boolean)tiler.composeGrid(grid);
		BufferedImage image = new BufferedImage( bounds.width,
				bounds.height, BufferedImage.TYPE_INT_ARGB);
		for( y=0 ; y<bounds.height ; y++) {
			for( x=0 ; x<bounds.width ; x++) {
				image.setRGB( x, y, 
					grid.booleanValue(x+bounds.x, y+bounds.y) ?
						0 : 0x80000000);
			}
		}
		Point2D p0 = new Point2D.Double(bounds.getX(), bounds.getY());
		XMap map = overlay.getXMap();
		p0 = map.getProjection().getMapXY( grid.getProjection().getRefXY(p0));
		Point2D p1 = new Point2D.Double(bounds.getX()+1., bounds.getY());
		p1 = map.getProjection().getMapXY( grid.getProjection().getRefXY(p1));
		double gridScale = p1.getX()<p0.getX() ?
			p1.getX()+map.getWrap()-p0.getX() :
			p1.getX() - p0.getX();
		overlay.setMaskImage(image, 
				p0.getX(),
				p0.getY(),
				gridScale);
	//	overlay.setGrid(grid, land, hasLand, hasOcean);
		return true;
	}
}
